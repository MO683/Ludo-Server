
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<title>Paytm CallBack</title>
</head>
<body>





<?php
header("Pragma: no-cache");
header("Cache-Control: no-cache");
header("Expires: 0");

// following files need to be included
require_once("./lib/config_paytm.php");
require_once("./lib/encdec_paytm.php");

$host = "localhost"; 
$user = "root"; 
$password = ""; 
$dbname = "ludo"; 

$con = mysqli_connect($host, $user, $password,$dbname);

$paytmChecksum = "";
$paramList = array();
$isValidChecksum = "FALSE";

$paramList = $_POST;
$paytmChecksum = isset($_POST["CHECKSUMHASH"]) ? $_POST["CHECKSUMHASH"] : ""; //Sent by Paytm pg

//Verify all parameters received from Paytm pg to your application. Like MID received from paytm pg is same as your application�s MID, TXN_AMOUNT and ORDER_ID are same as what was sent by you to Paytm PG for initiating transaction etc.
$isValidChecksum = verifychecksum_e($paramList, PAYTM_MERCHANT_KEY, $paytmChecksum); //will return TRUE or FALSE string.
?>


<div class="container text-center" style="margin-top: 30%;">
	<div class="card">
		<div class="card-header">
<?php if($isValidChecksum == "TRUE") {
	echo "<h1>Checksum matched and following are the transaction details</h1>";
	?>
	</div>
	<div class="card-body p-5">
	<?php
	if ($_POST["STATUS"] == "TXN_SUCCESS") {
		//Process your transaction here as success transaction.
		//Verify amount & order id received from Payment gateway with your application's order id and amount.
		$sql = "SELECT * FROM user_info WHERE order_id='".$_POST["ORDERID"]."'";
		$result = mysqli_query($con, $sql);
		

		$row = $result->fetch_assoc();
		$coin = $row["money"];
		$user_name = $row["nickname"];
		$coin = $coin + $_POST["TXNAMOUNT"];
		$sql = "UPDATE user_info SET money=".$coin." WHERE order_id='".$_POST["ORDERID"]."'";
		$result = mysqli_query($con, $sql);
		$con->close();

		echo "<h2>Transaction status is success"."USER ".$user_name."'s money is".$coin.  "</h2><br/>";
	}
	else {
		echo "<h3>Transaction status is failure</h3>" . "<br/><br/>";
		echo "<h3>Message From Paytm</h3>" . "<br/>";
		echo "<h4>".$_POST["RESPMSG"]."</h4>";
	}


}
else {
	echo "<b>Checksum mismatched.</b>";
	//Process transaction as suspicious.
}

?>
		</div>
	</div>
</div>
</body>
</html>