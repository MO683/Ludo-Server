
        <div class="container-fluid">
<?php
    $host = "localhost"; 
    $user = "root"; 
    $password = ""; 
    $dbname = "ludo"; 

    $conn = mysqli_connect($host, $user, $password,$dbname);
    $sql = "SELECT nickname FROM user_info WHERE id=".$u_id;
    $result = mysqli_query($conn, $sql);
    if ($conn->connect_error) {
        die( 'DB ERROR:' . mysqli_connect_error());
    }

    $row = $result->fetch_assoc();
    $user_name = $row["nickname"];
    $conn->close();
?>
<!-- Page Heading -->
<h1 class="h3 mb-2 text-gray-800">User Money Transfer ( <?php echo $user_name?> )</h1>
<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-body">
      <div class="table-responsive">
        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-xl-6 col-lg-6 col-md-6">

                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                    <!-- Nested Row within Card Body -->
                        <div class="row">
                            <!--div class="col-lg-6 d-none d-lg-block bg-login-image"></div-->
                            <div class="col-lg-12">
                                <div class="p-5">
                                    <!--form class="user" action="<?php echo base_url('user-money-transfer');?>/<?php echo $u_id?>" method="post"-->
                                    <form class="user" action="http://54.65.185.106/ludowala/PaytmKit/pgRedirect.php" method="post" target="_blank">
                                    <?php
                                        if($this->session->flashdata('message')){
                                            echo $this->session->flashdata('message');
                                        }
                                    ?>  
                                    <?php
                                        if($this->session->flashdata('message')){
                                        echo $this->session->flashdata('message');
                                        }
                                    ?>
                                    <div class="form-group">
                                        <h3>ORDER_ID.</h3><input class="form-control form-control-user" id="ORDER_ID" tabindex="1" maxlength="20" size="20" name="ORDER_ID" autocomplete="off" value="<?php echo  "ORDS" . rand(10000,99999999)?>">
                                    </div>  
                                    <div class="form-group">
                                        <h3>Please input the money.</h3><input type="text" class="form-control form-control-user" id="TXN_AMOUNT" name="TXN_AMOUNT" placeholder="Money">
                                    </div>
                                    <div class="form-group">
                                        <h3>Please input the INDUSTRY_TYPE_ID.</h3><input type="text" class="form-control form-control-user" id="INDUSTRY_TYPE_ID" name="INDUSTRY_TYPE_ID" value="Retail" placeholder="INDUSTRY ID">
                                    </div>
                                    <div class="form-group">
                                        <h3>Please input the channel ID.</h3><input type="text" class="form-control form-control-user" id="CHANNEL_ID" name="CHANNEL_ID" value="WEB">
                                    </div>
                                    <input type='hidden' id="CUST_ID" name="CUST_ID" value='<?php echo $u_id?>'>
                                    <input type='submit' value='Transfer' class='btn btn-primary btn-user btn-block'>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->

<!-- Page level plugins -->
<script src="<?php echo base_url(); ?>assets/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Page level custom scripts -->
<script src="<?php echo base_url(); ?>assets/js/demo/datatables-demo.js"></script>

