<script>
    function popup_delete(u_id)
    {
      var php_var = "<?php echo base_url('room-delete')?>" + "/" + u_id;
      $("#delete_href").attr("href", php_var);
      $('#deleteModal').modal('show');
    }
</script>
 
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Room List
              <a href="" class="btn btn-success btn-icon-split align-right" style="float: right;margin-top: -5px;">
                <span class="icon text-white-50">
                  <i class="fas fa-check"></i>
                </span>
                <span class="text">Refresh</span>
              </a>
			  <a href="<?php echo base_url('add-room')?>" class="btn btn-primary btn-icon-split align-right" style="float: right;margin-top: -5px;">
                <span class="icon text-white-50">
                  <i class="fas fa-plus"></i>
                </span>
                <span class="text">Add Room</span>
              </a>
          </h1>
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-body">
              <div class="table-responsive">    
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th style="width:5%">&nbsp;</th>
                      <th style="width:20%">Room Name</th>
                      <th style="width:15%">Entry Coins</th>
                      <th style="width:15%">Wining Coins</th>
                      <th style="width:15%">PlayerAmount</th>
                      <th style="width:20%">Match Type</th>
                      <th>&nbsp;</th>
                    </tr>
                  </thead>                  
                  <tbody>
                  <?php
                    $i = 0;
                    foreach($bodydata as $entry)
                    {
                      $i++;
                  ?>
                    <tr>
                      <td><?php echo $i;?></td>
                      <td><?php echo $entry->room_name?></td>
                      <td><?php echo $entry->payoutcoin?></td>
                      <td><?php echo $entry->winning_coin?></td>
                      <td>
          					  <?php
                                  if ($entry->user_amount != "")
                                  {
          						?>
                                  <?php echo $entry->user_amount?>
          						<?php
          						}
                                  else
                                  {
          						?>
                                  0
          						<?php
                                  }
          						?>
          					  </td>

                      <td>
                        <?php
                                  if ($entry->matchtype == "1")
                                  {
                        ?>
                                  Private Room
                        <?php
                                  }
                                  else if($entry->matchtype == "2")
                                  {
                        ?>
                                  2 Player Room
                        <?php
                                  }
                                  else if($entry->matchtype == "4")
                                  {
                        ?>
                                  4 Player Room
                        <?php
                                  }
                        ?>
                      </td>
                      <td>
						          <?php
                        if ($entry->id != 0 && ($entry->user_amount == "" || $entry->user_amount == "0"))
                        {
                      ?>
                          <a href="#" class="btn btn-danger btn-icon-minus" onclick="javascript:popup_delete('<?php echo $entry->id?>');">
                          <span class="icon text-white-30">
                            <i class="fas fa-minus"></i>
                          </span>
                          <span class="text">Delete Room</span>
                        </a>
                      <?php
                        }
                      ?>
                      </td>
                    </tr>
                  <?php
                    }
                  ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

  <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Delete Room?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Do you want to delete selected room?</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-danger" id="delete_href" href="<?php echo base_url('room-delete')."/".$entry->id?>">Delete</a>
          </div>
        </div>
      </div>
  </div>

  <!-- Page level plugins -->
  <script src="<?php echo base_url(); ?>assets/vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="<?php echo base_url(); ?>assets/js/demo/datatables-demo.js"></script>


 
