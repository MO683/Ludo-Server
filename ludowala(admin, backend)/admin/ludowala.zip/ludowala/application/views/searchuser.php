
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Search Users
              <a href="" class="btn btn-success btn-icon-split align-right" style="float: right;margin-top: -5px;">
                <span class="icon text-white-50">
                  <i class="fas fa-check"></i>
                </span>
                <span class="text">Refresh</span>
              </a>
          </h1>
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-body">
              <div class="table-responsive">    
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th style="width:5%">&nbsp;</th>
                      <th style="width:20%">Nickname</th>
                      <th style="width:15%">Email</th>
                      <th style="width:15%">Phone number</th>
                      <th style="width:15%">Money</th>
                      <th></th>
                    </tr>
                  </thead>                  
                  <tbody>
                  <?php
                    $i = 0;
                    foreach($bodydata as $entry)
                    {
                      $i++;
                  ?>
                    <tr>
                      <td><?php echo $i;?></td>
                      <td>
                      <?php
                        if ($entry['u_photoURL'] != "")
                        {
                      ?>
                          <img class="img" id="myImg" class='img-rounded' src="<?php echo $entry['u_photoURL']?>" style='width:50px;height:50px;margin:3px;border-radius:50px'/>
                      <?php
                        }
                        else
                        {
                      ?>
                          <img class="img" id="myImg" class='img-rounded' src="http://127.0.0.1:10008/useravata/<?php echo $entry['u_photoindex']?>.png" style='width:50px;height:50px;margin:3px;border-radius:50px'/>
                      <?php
                        }
                      ?><?php echo $entry['u_id']?></td>
                      <td><?php echo $entry['u_email']?></td>
                      <td><?php echo $entry['u_phone']?></td>
                      <td><?php echo ($entry['u_balance'] + $entry['u_buyinmoney']) ?></td>
                      <td>
                        <!--a href="<?php echo base_url('game-stats')."/".$entry['u_id']?>" class="btn btn-warning btn-icon-split">
                          <span class="icon text-white-50">
                            <i class="fas fa-exclamation-triangle"></i>
                          </span>
                          <span class="text">Game Stats</span>
                        </a-->
                        <a href="<?php echo base_url('deposit-history')."/".$entry['u_id']?>" class="btn btn-info btn-icon-split">
                          <span class="icon text-white-50">
                            <i class="fas fa-credit-card"></i>
                          </span>
                          <span class="text">Deposit</span>
                        </a>
                        <a href="<?php echo base_url('withdraw-history')."/".$entry['u_id']?>" class="btn btn-primary btn-icon-split">
                          <span class="icon text-white-50">
                            <i class="fa fa-arrow-right"></i>
                          </span>
                          <span class="text">Withdrawal</span>
                        </a>
                      </td>
                    </tr>
                  <?php
                    }
                  ?>
                  </tbody>
                </table>
              </div>
              <!--div style="text-align:center"><?php echo $bodydata["links"]; ?></div-->
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

  <!-- Page level plugins -->
  <script src="<?php echo base_url(); ?>assets/vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="<?php echo base_url(); ?>assets/js/demo/datatables-demo.js"></script>
