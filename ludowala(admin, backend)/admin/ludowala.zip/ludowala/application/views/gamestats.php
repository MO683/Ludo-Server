
        <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">Game Stats for <?php echo $flag?>
            <a href="" class="btn btn-success btn-icon-split align-right" style="float: right;margin-top: -5px;">
            <span class="icon text-white-50">
                <i class="fas fa-check"></i>
            </span>
            <span class="text">Refresh</span>
            </a>
        </h1>
        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-body">
              <div class="table-responsive">    
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th style="width:5%">&nbsp;</th>
                      <th style="width:20%">Nickname</th>
                      <th style="width:20%">Level</th>
                      <th style="width:20%">Points</th>
                      <th></th>
                    </tr>
                  </thead>                  
                  <tbody>
                  <?php
                    $i = 0;
                    foreach($bodydata as $entry)
                    {
                      $i++;
                  ?>
                    <tr>
                      <td><?php echo $i;?></td>
                      <td>
                        <img class="img" id="myImg" class='img-rounded' src="<?php echo $entry['photo']?>" style='width:50px;height:50px;margin:3px;border-radius:50px'/>
                        <?php echo $entry['id']?>
                      </td>
                      <td><?php echo $entry['level']?></td>
                      <td><?php echo $entry['balance']?></td>
                      <td>&nbsp;</td>
                    </tr>
                  <?php
                    }
                  ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

  <!-- Page level plugins -->
  <script src="<?php echo base_url(); ?>assets/vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="<?php echo base_url(); ?>assets/js/demo/datatables-demo.js"></script>

