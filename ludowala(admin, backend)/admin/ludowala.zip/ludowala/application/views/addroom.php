
        <div class="container-fluid">

<!-- Page Heading -->
<h1 class="h3 mb-2 text-gray-800">Create Room</h1>
<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-body">
      <div class="table-responsive">
        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-xl-6 col-lg-6 col-md-6">

                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                    <!-- Nested Row within Card Body -->
                        <div class="row">
                            <!--div class="col-lg-6 d-none d-lg-block bg-login-image"></div-->
                            <div class="col-lg-12">
                                <div class="p-5">
                                    <form class="user" action="<?php echo base_url('add-room')?>" method="post">
                                    <?php
                                        if($this->session->flashdata('message')){
                                            echo $this->session->flashdata('message');
                                        }
                                    ?>  
                                    <div class="form-group">
                                        <h3>Please input the Room Name.</h3><input type="text" class="form-control form-control-user" id="room_name" name="room_name" placeholder="Room Name">
                                    </div>
                                    <div class="form-group">
                                        <h3>Please input the Entry coin.</h3><input type="number" class="form-control form-control-user" id="coin" name="coin" placeholder="Entry Coin Amount">
                                    </div>
                                    <div class="form-group">
                                        <h3>Please input the Winner coin.</h3><input type="number" class="form-control form-control-user" id="wincoin" name="wincoin" placeholder="Winner Coin Amount">
                                    </div>
                                    <div class="form-group">
                                        <h3>Please input the Match Type.</h3>
                                        <input type="radio" name="matchtype" id="matchtype" value="1">Private Game
                                        <input type="radio" name="matchtype" id="matchtype" value="2">2 Player Game
                                        <input type="radio" name="matchtype" id="matchtype" value="4">4 Player Game
                                    </div>
                                    <input type='submit' value='Add Room' class='btn btn-primary btn-user btn-block'>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->

<!-- Page level plugins -->
<script src="<?php echo base_url(); ?>assets/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Page level custom scripts -->
<script src="<?php echo base_url(); ?>assets/js/demo/datatables-demo.js"></script>

