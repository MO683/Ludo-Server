<script>
    function popup_delete(u_id)
    {
      var php_var = "<?php echo base_url('notify-delete')?>" + "/" + u_id;
      $("#delete_href").attr("href", php_var);
      $('#deleteModal').modal('show');
    }
</script>
        <div class="container-fluid">
<?php 
    $host = "localhost"; 
    $user = "root"; 
    $password = ""; 
    $dbname = "ludo"; 

    $conn = mysqli_connect($host, $user, $password,$dbname);
    $sql = "UPDATE notify_table SET status=1";
    $result = mysqli_query($conn, $sql);
    if ($conn->connect_error) {
        die( 'DB ERROR:' . mysqli_connect_error());
    }
    $conn->close();
?>
              

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Notification</h1>
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th style="width:5%">&nbsp;</th>
                      <th style="width:15%">UserID</th>
                      <th style="width:20%">Nickname</th>
                      <th style="width:15%">Paytm Number</th>
                      <th style="width:10%">Amount</th>
                      <th style="width:20%">Date</th>
                      <th>&nbsp;</th>
                    </tr>
                  </thead>                  
                  <tbody>
                  <?php
                    $i = 0;
                    foreach($bodydata as $entry)
                    {
                      $i++;
                  ?>
                    <tr>
                      <td><?php echo $i;?></td>
                      <td><?php echo $entry->user_id?></td>
                      <td><?php echo $entry->name?></td>
                      <td><?php echo $entry->paytmPhone?></td>
                      <td><?php echo $entry->money?></td>
                      <td><?php echo $entry->date?></td>
                      <td>
                        <a href="#" class="btn btn-danger btn-icon-split" onclick="javascript:popup_delete('<?php echo $entry->id?>');">
                          <span class="icon text-white-50">
                            <i class="fas fa-trash"></i>
                          </span>
                          <span class="text">Remove</span>
                        </a>
                      </td>
                    </tr>
                  <?php
                    }
                  ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

    <!-- Logout Modal-->
        <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Delete history?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span>
                </button>
              </div>
              <div class="modal-body">Do you want to delete selected history?</div>
              <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-primary" id="delete_href" href="<?php echo base_url('notify-delete')."/".$entry->id?>">Delete</a>
              </div>
            </div>
          </div>
        </div>

  <!-- Page level plugins -->
  <script src="<?php echo base_url(); ?>assets/vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="<?php echo base_url(); ?>assets/js/demo/datatables-demo.js"></script>

  
  <?php
  if($i == 0)
    {
  ?>
      <div>
  <?php
    }
  ?>