
<script>
    function popup_getback(u_id)
    {
      var php_var = "<?php echo base_url('user-money-getback')?>" + "/" + u_id;
      $("#getback_href").attr("href", php_var);
      $('#getbackModal').modal('show');
    }
</script>

<div class="container-fluid">

	<!-- Page Heading -->
	<h1 class="h3 mb-2 text-gray-800">User Money Segment
		<a href="" class="btn btn-success btn-icon-split align-right" style="float: right;margin-top: -5px;">
		  <span class="icon text-white-50">
			<i class="fas fa-check"></i>
		  </span>
		  <span class="text">Refresh</span>
		</a>
	</h1>
	<!-- DataTales Example -->
	<div class="card shadow mb-4">
	  <div class="card-body">
		<div class="table-responsive">    
		  <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
			<thead>
			  <tr>
				<th style="width:5%">&nbsp;</th>
				<th style="width:20%">Nickname</th>
				<th style="width:20%">Email</th>
				<th style="width:20%">Phone number</th>
				<th style="width:15%">Money</th>				
			  </tr>
			</thead>			
			<tbody>
			<?php
			  $i = 0;
			  foreach($bodydata as $entry)
			  {
				$i++;
			?>
			  <tr>
				<td><?php echo $i;?></td>
				<td>
				<?php
				  if ($entry->avatar != "")
				  {
				?>
					<img class="img" id="myImg" class='img-rounded' src="<?php echo $entry->avatar?>" style='width:50px;height:50px;margin:3px;border-radius:50px'/>
				<?php
				  }
				  else
				  {
				?>
					<img class="img" id="myImg" class='img-rounded' src="assets/img/male.png" style='width:50px;height:50px;margin:3px;border-radius:50px'/>
				<?php
				  }
				?><?php echo $entry->nickname?></td>
				<td><?php echo $entry->email?></td>
				<td><?php echo $entry->phone?></td>
				<td><?php echo $entry->money?></td>
				<!-- <td>
				  <a href="<?php echo base_url('user-money-transfer')."/".$entry->id?>" class="btn btn-danger btn-icon-split">
					<span class="icon text-white-50">
					  <i class="far fa-money-bill-alt"></i>
					</span>
					<span class="text">Transfer</span>
				  </a> -->
				  <!--a href="#" class="btn btn-success btn-icon-split" onclick="javascript:popup_getback('<?php echo $entry->nickname?>');">
					<span class="icon text-white-50">
					  <i class="far fa-money-bill-alt"></i>
					</span>
					<span class="text">Get back</span>
				  </a--> 
				<!-- </td> -->
			  </tr>
			<?php
			  }
			?>
			</tbody>
		  </table>
		</div>
		<!--div style="text-align:center"><?php echo $bodydata["links"]; ?></div-->
	  </div>
	</div>

</div>
<!-- /.container-fluid -->

<!-- Page level plugins -->
<script src="<?php echo base_url(); ?>assets/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Page level custom scripts -->
<script src="<?php echo base_url(); ?>assets/js/demo/datatables-demo.js"></script>

<!-- Logout Modal-->
<div class="modal fade" id="getbackModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Get Back Money</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
        </div>
        <div class="modal-body">Do you want to get back money?</div>
        <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal">NO</button>
        <a class="btn btn-primary" id="getback_href" href="<?php echo base_url('user-money-getback')."/".$entry->id?>">YES</a>
        </div>
    </div>
    </div>
</div>
