<script>
    function popup_delete(u_id)
    {
      var php_var = "<?php echo base_url('user-delete')?>" + "/" + u_id;
      $("#delete_href").attr("href", php_var);
      $('#deleteModal').modal('show');
    }
</script>
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Blocked Users</h1>
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th style="width:5%">&nbsp;</th>
                      <th style="width:20%">Nickname</th>
                      <th style="width:20%">Email</th>
                      <th style="width:20%">Phone number</th>
                      <th style="width:15%">Money</th>
                      <th>&nbsp;</th>
                    </tr>
                  </thead>                  
                  <tbody>
                  <?php
                    $i = 0;
                    foreach($bodydata as $entry)
                    {
                      $i++;
                  ?>
                    <tr>
                      <td><?php echo $i;?></td>
                      <td>
                      <?php
                        if ($entry->avatar != "")
                        {
                      ?>
                          <img class="img" id="myImg" class='img-rounded' src="<?php echo $entry->avatar?>" style='width:50px;height:50px;margin:3px;border-radius:50px'/>
                      <?php
                        }
                        else
                        {
                      ?>
                          <img class="img" id="myImg" class='img-rounded' src="assets/img/male.png" style='width:50px;height:50px;margin:3px;border-radius:50px'/>
                      <?php
                        }
                      ?><?php echo $entry->nickname?></td>
                      <td><?php echo $entry->email?></td>
                      <td><?php echo $entry->phone?></td>
                      <td><?php echo $entry->money?></td>
                      <td>
                        <a href="<?php echo base_url('user-unblock')."/".$entry->id?>" class="btn btn-primary btn-icon-split">
                          <span class="icon text-white-50">
                            <i class="fas fa-flag"></i>
                          </span>
                          <span class="text">Unblock</span>
                        </a>
                        <a href="#" class="btn btn-danger btn-icon-split" onclick="javascript:popup_delete('<?php echo $entry->id?>');">
                          <span class="icon text-white-50">
                            <i class="fas fa-trash"></i>
                          </span>
                          <span class="text">Remove</span>
                        </a>
                      </td>
                    </tr>
                  <?php
                    }
                  ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

    <!-- Logout Modal-->
        <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Delete User?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span>
                </button>
              </div>
              <div class="modal-body">Do you want to delete selected user?</div>
              <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-primary" id="delete_href" href="<?php echo base_url('user-delete')."/".$entry->nickname?>">Delete</a>
              </div>
            </div>
          </div>
        </div>

  <!-- Page level plugins -->
  <script src="<?php echo base_url(); ?>assets/vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="<?php echo base_url(); ?>assets/js/demo/datatables-demo.js"></script>

  
  <?php
  if($i == 0)
    {
  ?>
      <div>
  <?php
    }
  ?>