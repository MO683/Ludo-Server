<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<title>BuyCoin</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>
<body>

<div class="container pt-5">
	<div class="card text-center">
	  <img class="card-img" src="<?php echo base_url()?>/assets/img/ludoback.png" alt="Card image" >
	  <div class="card-img-overlay">
	    <div class="card-text mt-5">
			<div style="margin-top: 15rem;">
				<label for="phone">Your Phone Number</label>
				<h4 id="phone" name="phone"><?php echo $userinfo->phone;?></h4>

				<label for="phone">Your Name</label>
				<h4 id="phone" name="phone"><?php echo $userinfo->nickname;?></h4>
				<h2>Your Request coin amount is</h2>
				<h3><?php echo $money?></h3>
			</div>

			<form class="user" action="http://54.65.185.106/ludowala/PaytmKit/paytmBuyCoin.php" method="post" target="_blank">
                <input type="hidden" class="form-control form-control-user" id="ORDER_ID" tabindex="1" name="ORDER_ID"  value="<?php echo  "ORDS" . rand(10000,99999999)?>">
                <input type="hidden" class="form-control form-control-user" id="TXN_AMOUNT" name="TXN_AMOUNT" placeholder="Money" value="<?php echo $money;?>">
                <input type="hidden" class="form-control form-control-user" id="INDUSTRY_TYPE_ID" name="INDUSTRY_TYPE_ID" value="Retail" placeholder="INDUSTRY ID">
                <input type="hidden" class="form-control form-control-user" id="CHANNEL_ID" name="CHANNEL_ID" value="WEB">
                <input type='hidden' id="CUST_ID" name="CUST_ID" value='<?php echo $userinfo->id;?>'>
                <input type='submit' value='Confirm' class='btn btn-primary'></button>
            </form>
	    </div>
	  </div>
	</div>
</div>
</body>
</html>