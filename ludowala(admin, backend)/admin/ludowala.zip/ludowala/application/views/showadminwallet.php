

<div class="container-fluid">

	<!-- Page Heading -->
	<h1 class="h3 mb-2 text-gray-800">User Money Segment
		<a href="" class="btn btn-success btn-icon-split align-right" style="float: right;margin-top: -5px;">
		  <span class="icon text-white-50">
			<i class="fas fa-check"></i>
		  </span>
		  <span class="text">Refresh</span>
		</a>
	</h1>
	<!-- DataTales Example -->
	<div class="card shadow mb-4">
	  <div class="card-body">
		<div class="table-responsive">    
		  <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
			<thead>
			  <tr>
				<th style="width:5%">&nbsp;</th>
				<th style="width:25%">Admin Coins</th>
				<th style="width:25%">Total Admin Coins</th>
				<th style="width:30%">DATE</th>
				<!-- <th>&nbsp;</th> -->
			  </tr>
			</thead>			
			<tbody>
			<?php
			  $i = 0;
			  foreach($bodydata as $entry)
			  {
				$i++;
			?>
			  <tr>
				<td><?php echo $i;?></td>
				<td><?php echo $entry->add_amount?></td>
				<td><?php echo $entry->total_amount?></td>
				<td><?php echo $entry->date?></td>
				<!-- <td>
				<?php
                if ($entry->total_amount != "" || $entry->total_amount != "0")
                {
                ?>
                    <a href="<?php echo base_url('admin-money-transfer')."/".$entry->id?>" class="btn btn-danger btn-icon-split">
					<span class="icon text-white-50">
						<i class="far fa-money-bill-alt"></i>
					</span>
					<span class="text">Transfer</span>
					</a>
                <?php
                }
                ?>
				  
				</td> -->
			  </tr>
			<?php
			  }
			?>
			</tbody>
		  </table>
		</div>
		<!--div style="text-align:center"><?php echo $bodydata["links"]; ?></div-->
	  </div>
	</div>

</div>
<!-- /.container-fluid -->

<!-- Page level plugins -->
<script src="<?php echo base_url(); ?>assets/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Page level custom scripts -->
<script src="<?php echo base_url(); ?>assets/js/demo/datatables-demo.js"></script>


