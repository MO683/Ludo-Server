<?php
class User_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();        
    }   
    
    //enable two factor authentication for users
    function enable_tfa($user_id,$secret_code)
    {
			$this->db->where('id',$user_id);
			$data=array(
						'secret'  => $secret_code,
						'randcode'  => "enable"
					  );
			return $this->db->update('users',$data);	
	 }
	
	 //disable two factor authentication for users
	 function disable_tfa($user_id,$secret_code)
     {
			$this->db->where('id',$user_id);
			$data=array(
						'secret'  => '',
						'randcode'  => "disable"
					  );
			return $this->db->update('users',$data);		
	  }		

    function checktfa()
    {
        $this->load->library('Googleauthenticator');
        $ga     = new Googleauthenticator();
        $email  =  $this->session->userdata('email');
        $result = $this->common_model->getTableData('users', array('email' => $email))->row_array();
        $code   = $this->input->post('onecode');
        if(count($result)){
			$secret = $result['secret'];
			$oneCode = $ga->verifyCode($secret,$code,$discrepancy = 3);
			if($oneCode==1)
			{
				return true;
			}
			else
			{
				return false;
			}
	   }else
	   return false;
    }
    
     function checktfa_app()
    {
        $this->load->library('Googleauthenticator');
        $ga     = new Googleauthenticator();
        $email  =  $this->input->get_post('email');
        $result = $this->common_model->getTableData('users', array('email' => $email))->row_array();
        $code   = $this->input->get_post('onecode');
        if(count($result)){
			$secret = $result['secret'];
			$oneCode = $ga->verifyCode($secret,$code,$discrepancy = 3);
			if($oneCode==1)
			{
				return true;
			}
			else
			{
				return false;
			}
	   }else
	   return false;
    }
    
    //get trade order
    function gettradeorder($trade_id){
		$this->db->select('*');
		$this->db->from('trade_details T');
		$this->db->join('users U', 'U.id=T.userId', 'left');
		$this->db->where('trade_id',$trade_id);
		$Q = $this->db->get();
		return $Q->row_array();
	}
	
	function getlastorder($firstCurrency, $secondCurrency){
		$this->db->where('firstCurrency',$firstCurrency);
		$this->db->where('secondCurrency',$secondCurrency);
		$this->db->where('Status','Completed');
		$this->db->order_by('trade_id','DESC');
		$result = $this->db->get('trade_details')->result_array();		
		if(count($result))
		return $result[0];
		else
		return false;
	}
	
	//get trade pairs
	function lasttradeprices(){
		$trade_pairs = $this->common_model->getTableData('trade_pairs', array('status' => 'active'))->result_array();
		$pairs = array();
		if(count($trade_pairs)){
			foreach($trade_pairs as $trade_pair){
				if($trade = $this->getlastorder($trade_pair['from_symbol'], $trade_pair['to_symbol']))
				$pairs[$trade_pair['pair_symbol']] = $trade['Price'];
				else
			    $pairs[$trade_pair['pair_symbol']] = 0;
			}
		}		
		return  $pairs;
	}
    
    //cancel trade order
    function canceltradeorder($trade_id){
		$order = $this->gettradeorder($trade_id);
		if(count($order) && $order['Status'] == 'Pending'){
			$this->db->where('trade_id', $trade_id);
			$this->db->update('trade_details', array('Status'=>'Cancelled'));
			
			if($order['Type'] == 'Sell'){
			   $refundAmount = to_decimal($order['Amount']).' '.$order['firstCurrency'];
			   $this->db->query('UPDATE wallet SET '.$order['firstCurrency'].'=('.$order['firstCurrency'].'+'.(float)$order['Amount'].') WHERE user_id="'.$order['userId'].'"', '', false);
			}else{
				$refundAmount = to_decimal($order['Total']).' '.$order['secondCurrency'];
			   $this->db->query('UPDATE wallet SET '.$order['secondCurrency'].'=('.$order['secondCurrency'].'+'.(float)$order['Total'].') WHERE user_id="'.$order['userId'].'"', '', false);
	     	}
		
			if(isset($order['email']) && trim($order['email']) != ''){	
					$email_template = 'Trading order status';
					$special_vars = array(
						'###SITELOGO###' => getSiteLogo(),
						'###SITENAME###' => getSiteName(),
						'###SITELINK###' => base_url(),
						'###USERNAME###'=>$order['username'],
						'###TYPE###'=>$order['Type'],
						'###AMOUNT###'=>$order['Amount'],
						'###CURRENCY###'=>$order['firstCurrency'],
						'###PRICE###'=>$order['Price'].' '.$order['secondCurrency'],
						'###FINAL###'=>$order['Total'].' '.$order['secondCurrency'],
						'###FEES###'=>$order['Fee'].' '.(($order['Type']=='Buy')?$order['firstCurrency']:$order['secondCurrency']),
						'###STATUS###' => 'Cancelled'						
						);
					//-----------------
					$this->email_model->sendMail($order['email'], '', '', $email_template, $special_vars);				
			}
			
			return $refundAmount;
		}else
		return false;
	}
	
	//currency convert
	function currency_convert_manual($symbol){
		$this->db->where('pair_symbol', $symbol);
		$q = $this->db->get('pair');
		$result = $q->row_array();
		if(count($result))
		return $result['rate_value'];
		else
		return 1;
	}
	
	//get deicount level for specific customer
	function my_discount_level($user_id){
		$total  = 0;
		$this->db->select('*');
		$this->db->from('trade_details');
		$this->db->where('userId', $user_id);
		$this->db->where('Status != ', 'Cancelled');
		$this->db->group_by('MONTH(orderDate)');
		$q = $this->db->get();
		$monthsCount = $q->num_rows();
		
		if($monthsCount>0){
		
			$this->db->select('sum(Amount) as Totalvalue, firstCurrency as currency');
			$this->db->from('trade_details');
			$this->db->where('userId', $user_id);
			$this->db->where('Type', 'Sell');
			$this->db->where('Status != ', 'Cancelled');
			$q = $this->db->get();
			$results = $q->result_array();
			if(count($results)){
				foreach($results as $result){
					if($result['currency'] == 'CAD')
					   $total += (float)$result['Totalvalue'];
					else{
						$CADValue = $this->currency_convert_manual($result['currency'].'/CAD');
						$total += ((float)$CADValue*(float)$result['Totalvalue']);
					}
				}
			}
			
			$this->db->select('sum(Total) as Totalvalue, secondCurrency as currency');
			$this->db->from('trade_details');
			$this->db->where('Type', 'Buy');
			$this->db->where('Status != ', 'Cancelled');
			$q = $this->db->get();
			$results = $q->result_array();
			if(count($results)){
				foreach($results as $result){
					if($result['currency'] == 'CAD')
					   $total += (float)$result['Totalvalue'];
					else{
						$CADValue = googlecurrencyconvert(1,$result['currency'], 'CAD');
						$total += ((float)$CADValue*(float)$result['Totalvalue']);
					}
				}
			}
			$permonth = (($total>0)?($total/$monthsCount):0);
		}else
		$total = $permonth =  0;
		
		$this->db->where('range_from<=', $permonth);
		$this->db->order_by('discount_value', 'DESC');
		$q = $this->db->get('discounts');
		$discounts = $q->result_array();
		if(count($discounts))
			$current_level = (float)$discounts[0]['discount_value'];
		else
		$current_level = 0;
		
		$this->db->where('range_from>=', $permonth);
		$this->db->order_by('discount_value', 'ASC');
		$q = $this->db->get('discounts');
		$discounts = $q->result_array();	
		if(count($discounts)){
			$next_level = (float)$discounts[0]['discount_value'];
			$next_level_diff = (float)$discounts[0]['range_from'] - $permonth;
		}else{
		   $next_level = 0;
		   $next_level_diff = 0;
	    }
		
		return array('monthsCount'=>$monthsCount,'total'=>$total, 'permonth'=>$permonth, 'current_level'=>$current_level, 'next_level'=>$next_level, 'next_level_diff'=>$next_level_diff);
	  
	}
	
	
	 //create bitcoin address
	function create_bitcoin_address(){
		$access_token = 'v2xaf7581a5db7b3dbc277b4def9854f7a1c42c56451c12e4dfab6749df5c77601a';
		$wallet_id = '3GibZ8bMUP1bRV7tn1sawEp5jhqmS39qN4';
		$gateways = $this->common_model->getTableData('payment_gateways', array('status' => '1','currency_symbol'=>'BTC'))->row_array();
        $access_token =$gateways['access_token'];
        $wallet_id =$gateways['wallet_id'];
        $wallet_password = $gateways['wallet_password'];
		//$createAddress = $createAddress = shell_exec('curl -X GET -H "Authorization: Bearer '.trim($access_token).'" https://test.bitgo.com/api/v1/user/me');
		$output = array();
		$return_var = -1;
		$createAddress = exec('cd /home/conne722/BitGoJS/example; node createaddress.js '.$access_token.' '.$wallet_id.' test', $output, $return_var);
		if($createAddress && !empty($createAddress)){	
			$createAddressJson = json_decode($createAddress, true);
			return $createAddressJson['address'];
	    }else{
			return false;
		}
	}
	 //get bitcoin address balance
	function bitcoin_address_balance($address){
		$access_token = 'v2xaf7581a5db7b3dbc277b4def9854f7a1c42c56451c12e4dfab6749df5c77601a';
		$wallet_id = '3GibZ8bMUP1bRV7tn1sawEp5jhqmS39qN4';
		$gateways = $this->common_model->getTableData('payment_gateways', array('status' => '1','currency_symbol'=>'BTC'))->row_array();
        $access_token =$gateways['access_token'];
        $wallet_id =$gateways['wallet_id'];
        $wallet_password = $gateways['wallet_password'];
		$output = array();
		$return_var = -1;
		$Addresstransactions = exec('cd /home/conne722/BitGoJS/example; node addressBalance.js '.$access_token.' '.$wallet_id.' test '.$address.'', $output, $return_var);
		if($Addresstransactions && !empty($Addresstransactions)){	
			$AddresstransactionsJson = json_decode($Addresstransactions, true);
			return $AddresstransactionsJson;
	    }else{
			return false;
		}
	}
	
	
    //get all transactions 
	function get_bitcoin_transactions(){		
		$access_token = 'v2xaf7581a5db7b3dbc277b4def9854f7a1c42c56451c12e4dfab6749df5c77601a';
		$wallet_id = '3GibZ8bMUP1bRV7tn1sawEp5jhqmS39qN4';
		$gateways = $this->common_model->getTableData('payment_gateways', array('status' => '1','currency_symbol'=>'BTC'))->row_array();
        $access_token =$gateways['access_token'];
        $wallet_id =$gateways['wallet_id'];
        $wallet_password = $gateways['wallet_password'];
		//$createAddress = $createAddress = shell_exec('curl -X GET -H "Authorization: Bearer '.trim($access_token).'" https://test.bitgo.com/api/v1/user/me');
		$output = array();
		$return_var = -1;

		$transactions = exec('cd  /home/conne722/BitGoJS/example; node transactions.js '.$access_token.' '.$wallet_id.' test', $output, $return_var);
	

		if($transactions){
			$transactionsJson = json_decode($transactions, true);		
			return $transactionsJson['transactions'];
		}else
		return array();
	}
	
	
	//send amount to specified address
	function send_bitcoin_transaction($address, $amount){		
		$access_token = 'v2xaf7581a5db7b3dbc277b4def9854f7a1c42c56451c12e4dfab6749df5c77601a';
		$wallet_id = '3GibZ8bMUP1bRV7tn1sawEp5jhqmS39qN4';
		$wallet_password = 'Osiz@123Osiz@123';
		$gateways = $this->common_model->getTableData('payment_gateways', array('status' => '1','currency_symbol'=>'BTC'))->row_array();
        $access_token =$gateways['access_token'];
        $wallet_id =$gateways['wallet_id'];
        $wallet_password = $gateways['wallet_password'];
		//$createAddress = $createAddress = shell_exec('curl -X GET -H "Authorization: Bearer '.trim($access_token).'" https://test.bitgo.com/api/v1/user/me');
		$output = array();
		$return_var = -1;
		$transaction = exec('cd /home/conne722/BitGoJS/example; node sendtoaddress.js '.$access_token.' '.$wallet_id.' prod '.$wallet_password.' '.$amount.' '.$address.'', $output, $return_var);
		if($transaction && $return_var=='0'){
			$transactionsJson = json_decode($transaction, true);	
			return $transactionsJson;
		}else
		return false;
	}
	
	
	
	 //create ethereum address
	function create_ethereum_address(){
		$output = array();
		$return_var = -1;
		$createAddress = exec('cd /home/conne722/BitGoJS/example; node eth_createaddress.js', $output, $return_var);
		if($createAddress && !empty($createAddress)){	
			$createAddressJson = json_decode($createAddress, true);
			return $createAddressJson['address'];
	    }else{
			return $this->generateRandomString();
		}
	}
	
	function generateRandomString($length = 10) {
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		return $randomString;
	}
	
	
	//get all ethereum transactions 
	function get_ethereum_transactions($lastblock= '1727415'){		
		//$createAddress = $createAddress = shell_exec('curl -X GET -H "Authorization: Bearer '.trim($access_token).'" https://test.bitgo.com/api/v1/user/me');
		$output = array();
		$return_var = -1;
		$transactions = exec('cd /home/conne722/BitGoJS/example; node eth_transactions.js '.$lastblock.'', $output, $return_var);
    	if($transactions){
			$transactionsJson = json_decode($transactions, true);		
			return $transactionsJson['transactions'];
		}else
		return array();
	}
	
	
	//send amount to specified ethereum address
	function send_ethereum_transaction($address, $amount){		
		$fromaddress = 'v2xaf7581a5db7b3dbc277b4def9854f7a1c42c56451c12e4dfab6749df5c77601a';
		//$createAddress = $createAddress = shell_exec('curl -X GET -H "Authorization: Bearer '.trim($access_token).'" https://test.bitgo.com/api/v1/user/me');
		$output = array();
		$return_var = -1;
		$transaction = exec('cd /home/conne722/BitGoJS/example; node eth_sendtoaddress.js '.$fromaddress.' '.$address.' '.$amount.'', $output, $return_var);
		if($transaction && $return_var=='0'){
			$transactionsJson = json_decode($transaction, true);				
			return $transactionsJson;
		}else
		return false;
	}
	
	
	//add new transaction
	function add_transaction($data){
		$insert =  $this->db->insert('transactions',$data);
		$insert_id =  $this->db->insert_id();
		if($data['type'] == 'Withdraw'){
		 $this->db->query('UPDATE `wallet` SET `'.$data['currency_name'].'` = ('.$data['currency_name'].'-'.(float)$data['amount'].') WHERE user_id ='.$data['user_id'].'', false);
		}		
		
		   $userdetails = $this->common_model->getTableData('users', array('id' =>$data['user_id']))->row_array();
		//if(count($userdetails) && $userdetails['notify_deposit_withdraw'] == '1'){
		   $email_template = 'Transaction Order Created';
				
			$LINKSUSE = '';	
			if($data['type'] == 'Withdraw' && $data['currency_name'] == 'BTC'){
			   $LINKSUSE = 'To confirm your withdraw request, please click below link:<br/> <a href="'.site_url('verify_withdraw_confirm/'.$data['transaction_id']).'">'.site_url('verify_withdraw_confirm/'.$data['transaction_id']).'</a><br/>	<br/>
			   To cancel your withdraw request, please click below link:<br/> <a href="'.site_url('verify_withdraw_cancel/'.$data['transaction_id']).'">'.site_url('verify_withdraw_cancel/'.$data['transaction_id']).'</a>';	
			 } 	
			 	
			$special_vars = array(
					'###USERNAME###'=>$userdetails['username'],
					'###TYPE###'=>$data['type'],
					'###AMOUNT###'=>$data['amount'],
					'###FEES###'=>$data['fee'],
					'###FINAL###'=>(($data['type']=='Deposit')?$data['amount']:$data['paid_amount']),
					'###CURRENCY###'=>$data['currency_name'],
					'###STATUS###'=>'Placed',
					'###DATETIME###'=>$data['datetime'],
					'###SITELOGO###' => getSiteLogo(),
					'###SITENAME###' => getSiteName(),
					'###SITELINK###' => base_url(),
					'###USER###' => 'ConnectBTC Team',
					'###LINKSUSE###'=>$LINKSUSE,
					);
					
					
			//-----------------
			$this->email_model->sendMail($userdetails['email'], '', '', $email_template, $special_vars);
		
		//}
		
		if($data['type'] == 'Deposit' && $data['currency_name'] == 'CAD'){
				$site_settings = $this->common_model->getTableData('site_settings', array('id' => 1))->row();
				$email_template = 'Deposit Instructions - Quadriga Coin Exchange';
			    $special_vars = array(
					'###USERNAME###'=>$userdetails['username'],
					'###TYPE###'=>$data['type'],
					'###AMOUNT###'=>$data['amount'],
					'###FEES###'=>$data['fee'],
					'###FINAL###'=>(($data['type']=='Deposit')?$data['amount']:$data['paid_amount']),
					'###CURRENCY###'=>$data['currency_name'],
					'###STATUS###'=>'Placed',
					'###DATETIME###'=>$data['datetime'],
					'###SITELOGO###' => getSiteLogo(),
					'###SITENAME###' => getSiteName(),
					'###SITELINK###' => base_url(),
					'###TRANSACTIONID###' => $data['transaction_id'],
					'###BNAME###' => $site_settings->beneficiaryname,
					'###BADDRESS###' => $site_settings->beneficiaryaddress,
					'###BCITY###' => $site_settings->beneficiarycity,
					'###BPROVINCE###' => $site_settings->beneficiaryprovince,
					'###BPOSTALCODE###' => $site_settings->beneficiarypostalcode,
					'###BCOUNTRY###' => $site_settings->beneficiarycountry,
					'###BANKNAME###' => $site_settings->bank_name,
					'###BANKPHONE###' => $site_settings->bankphone,					
					'###BANKADDRESS###' => $site_settings->	bankaddress,
					'###BANKCITY###' => $site_settings->bankcity,
					'###BANKPROVINCE###' => $site_settings->bankprovince,
					'###BANKPOSTALCODE###' => $site_settings->bankpostalcode,
					'###BANKCOUNTRY###' => $site_settings->bank_country,
					'###ACCOUNTNUMBER###' => $site_settings->bank_account_number,
					'###TRANSITNUMBER###' => $site_settings->transitno,
					'###SWIFT###' => $site_settings->SWIFT,
					'###USER###' => 'ConnectBTC Team',
					);
			  $this->email_model->sendMail($userdetails['email'], '', '', $email_template, $special_vars);		
			}
			
			if($data['type'] == 'Deposit' && $data['currency_name'] == 'BTC'){	 //automatically complete transaction
			$details = $this->common_model->getTableData('transactions', array('trans_id' => $insert_id))->row();
		    $this->update_transaction_status($details, 'Completed', $data['paid_amount'], $data['wallet_txid']);
		 }  
		return $insert;
	}
	
	
	//update transaction status
	function update_transaction_status($details, $status, $amount, $wallet_txid=''){
		$data = array('status'=>$status, 'paid_amount'=>$amount, 'wallet_txid'=>$wallet_txid);
		if($status=='Completed')
		$data['payment_status'] = 'Paid';
		$where = array('trans_id'=>$details->trans_id);
		$this->db->update('transactions',$data, $where);		

        if($details->type == 'Deposit'){
			if($status=='Completed')
			$this->db->query('UPDATE `wallet` SET `'.$details->currency_name.'` = ('.$details->currency_name.'+'.(float)$amount.') WHERE user_id ='.$details->user_id.'', false);
		}else  if($details->type == 'Withdraw' && $status=='Cancelled'){
			$this->db->query('UPDATE `wallet` SET `'.$details->currency_name.'` = ('.$details->currency_name.'+'.(float)$amount.') WHERE user_id ='.$details->user_id.'', false);
		}
		
		if($status=='Completed'){
		 if($details->type == 'Deposit')
		 $this->db->query('UPDATE payment_gateways SET reserve_amount=(reserve_amount+'.(float)$amount.') WHERE currency_symbol="'.$details->currency_name.'"',false);
	 	 else  if($details->type == 'Withdraw')
     	 $this->db->query('UPDATE payment_gateways SET reserve_amount=(reserve_amount-'.(float)$amount.') WHERE currency_symbol ="'.$details->currency_name.'"',false);
	   }
     	 
		$userdetails = $this->db->get_where('users', array('id'=>$details->user_id))->row_array();
		if(count($userdetails) && $userdetails['notify_deposit_withdraw'] == '1'){
		   $email_template = 'Transaction Status';
			$special_vars = array(
			    '###USERNAME###'=>$userdetails['username'],
			    '###TYPE###'=>$details->type,
			    '###AMOUNT###'=>$amount,
			    '###FEES###'=>$details->fee,
			    '###FINAL###'=>$amount,
			    '###CURRENCY###'=>$details->currency_name,
			    '###STATUS###'=>$status,
			    '###DATETIME###'=>$details->datetime,
				'###SITELOGO###' => getSiteLogo(),
				'###SITENAME###' => getSiteName(),
				'###SITELINK###' => base_url(),
				'###USER###' => 'ConnectBTC Team',
				);
			//-----------------
            $this->email_model->sendMail($userdetails['email'], '', '', $email_template, $special_vars);
         }
         
	}
	
	
	//add new exchange order
	function add_order($data){
		$this->db->insert('order',$data);
		$newId =  $this->db->insert_id();
		
		
		if($data['user_id'] != '0')
		$userdetails = $this->db->get_where('users', array('id'=>$data['user_id']))->row_array();
		else
		$userdetails =  array('email'=>$data['email_address'], 'username'=>'User');
		
		$email_template = 'Quick Buy/Sell Order Placed';
		$special_vars = array(
			'###USERNAME###'=>$userdetails['username'],
			'###FROMCURRENCY###'=>$data['from_currency'],
			'###TOCURRENCY###'=>$data['to_currency'],
			'###FROMAMOUNT###'=>$data['send_amount'].' '.$data['from_currency'],
			'###TOAMOUNT###'=>$data['receive_amount'].' '.$data['to_currency'],
			'###EXCHANGEFEES###'=>$data['fees'] .' '.$data['from_currency'],
			'###FINAL###'=>$data['final_amount'].' '.$data['from_currency'],
			'###STATUS###'=>'Placed',
			'###DATETIME###'=>$data['datecreated'],
			'###SITELOGO###' => getSiteLogo(),
			'###SITENAME###' => getSiteName(),
			'###SITELINK###' => base_url(),
			'###USER###' => 'ConnectBTC Team',
			);
			//$userdetails['email'] = 'muthu@osiztechnologies.com';
		//-----------------
		$this->email_model->sendMail($userdetails['email'], '', '', $email_template, $special_vars);
            
        return $newId;
	}
	
	//update transaction status
	function update_order_status($details, $status, $amount, $wallet_txid=''){
		$data = array('receive_status'=>$status, 'to_wallet_txid'=>$wallet_txid);
		if($status=='Completed')
		$data['send_status'] = 'Completed';
		$where = array('order_id'=>$details->order_id);
		$this->db->update('order',$data, $where);		
     
	    if($details->user_id != '0')
		$userdetails = $this->db->get_where('users', array('id'=>$details->user_id))->row_array();
		else
		$userdetails =  array('email'=>$details->email_address, 'username'=>'User');
		
		if($status=='Completed'){
		 $this->db->query('UPDATE payment_gateways SET reserve_amount=(reserve_amount+'.(float)$details->final_amount.') WHERE currency_symbol="'.$details->from_currency.'"',false);
     	 $this->db->query('UPDATE payment_gateways SET reserve_amount=(reserve_amount-'.(float)$details->final_amount.') WHERE currency_symbol ="'.$details->to_currency.'"',false);
	   }
		
		//if(count($userdetails) && $userdetails['notify_deposit_withdraw'] == '1'){
		   $email_template = 'Exchange Order Status';
			$special_vars = array(
			    '###USERNAME###'=>$userdetails['username'],
			    '###FROMCURRENCY###'=>$details->from_currency,
			    '###TOCURRENCY###'=>$details->to_currency,
			    '###FROMAMOUNT###'=>$details->send_amount.' '.$details->from_currency,
			    '###TOAMOUNT###'=>$amount.' '.$details->to_currency,
			    '###EXCHANGEFEES###'=>$details->fees .' '.$details->from_currency,
			    '###FINAL###'=>$details->final_amount.' '.$details->from_currency,
			    '###STATUS###'=>$status,
			    '###DATETIME###'=>$details->datecreated,
				'###SITELOGO###' => getSiteLogo(),
				'###SITENAME###' => getSiteName(),
				'###SITELINK###' => base_url(),
				'###USER###' => 'ConnectBTC Team',
				);
				//$userdetails['email'] = 'muthu@osiztechnologies.com';
			//-----------------
            $this->email_model->sendMail($userdetails['email'], '', '', $email_template, $special_vars);
         //}   
	}
	
	
  
    function getFaqList()
    {
        $this->db->order_by('id', "desc");
        $query = $this->db->get('faq');
        if ($query->num_rows >= 1) {
            return $query->result();
        } else {
            return false;
        }
        
    }
    
    
    function getTestimonialsIndex()
    {
        $query = $this->db->order_by('feedback_id', 'desc');
        
        $query = $this->db->get_where('feedback', array(
            'status' => 'active'
        ), 3);
        
        if ($query->num_rows > 0) {
            return $query->result();
        } else {
            return false;
        }
    }
	

    function user_check_tfa()
    {
        $customer_user_id       =  $this->session->userdata('identity');
        $this->db->where('email',$customer_user_id);
        return $this->db->get('users');
    }
    
    function get_tfacode()
    {
        require_once 'GoogleAuthenticator.php';
        $ga = new PHPGangsta_GoogleAuthenticator();
        $data['secret'] = $ga->createSecret();
        //echo "Secret is: ".$secret."\n\n";
        $data['qrCodeUrl'] = $ga->getQRCodeGoogleUrl('Blog', $data['secret']);
        //echo "Google Charts URL for the QR-Code: ".$qrCodeUrl."\n\n";
        $data['oneCode'] = $ga->getCode($data['secret']);
        //echo "Checking Code '$oneCode' and Secret '$secret':\n";
        return $data;
    }


    

    function get_userstatus($user_id)
    {
        $this->db->where('id',$user_id);  
        $query=$this->db->get('users'); 
        if($query->num_rows == 1)
        {                
            $row = $query->row();            
            return $row->randcode;
        }   
        else
        {      
            return false;       
        }
    }
    function gatewayList()
    {
        
        $query =  $this->common_model->getTableData("payment_gateways",array('status' => 'active'));
        if ($query->num_rows > 0) {
            return $query->result();
        } else {
            return false;
        }
    }

    function barter_event($type,$start,$end,$userid){
         $this->db->select ( '*' )->from ( 'transaction' );
        if($type == "ALL"){
            $this->db->where('from_user_id ',$userid);
            $this->db->where("date_created >= '".$start."' AND date_created <= '".$end."'");
            //$this->db->where('date_created BETWEEN NOW() - INTERVAL '.$day.' DAY AND NOW()');
        }else{
            $this->db->where('from_user_id ',$userid);
            $this->db->where('type ',$type);
            $this->db->where("date_created >= '".$start."' AND date_created <= '".$end."'");
        }
         $query = $this->db->get();
        return $query;
       
    }


    function last_activity($email,$activity,$id='0'){      
        $date  = gmdate(time());
        $ip_address = $_SERVER['REMOTE_ADDR']; 
        $data = array('user_email'  => $email,
                        'date'      => $date,
                        'ip_address'=> $ip_address,
                        'activity'  => $activity,
                        'browser_name' => getBrowser(),
                        'os_name'  => getOS(),
                        'user_id'  => $id);      
        $this->common_model->insertTableData('user_activity',$data);
    }

    function last_ip_address(){

        $userid = $this->session->userdata('customer_user_id');
        $result = $this->common_model->getTableData('user_activity',array('user_id'=>$userid));
        return $result;
    }

    function update_referral_amount($amount,$id){
        $this->common_model->updateTableData('users',array('id'=>$id),array('refer_amount'=>$amount));
        if($this->db->affected_rows()){
            return true;
        }else{
            return false;
        }
    }

    function update_security_pin($pin,$new){
        $id  = $this->session->userdata('customer_user_id');
        if($new == ''){
            $this->common_model->updateTableData('users',array('id'=>$id),array('security_pin'=>$pin));
        }
        else{
            $this->common_model->updateTableData('users',array('id'=>$id),array('security_pin'=>$new));
        }
        if($this->db->affected_rows()){
            return true;
        }else{
            return false;
        }
    }

    function check_pin($pin){
        $userid  = $this->session->userdata('customer_user_id');
        $result  = $this->common_model->getTableData('users',array('id'=>$userid));
        return $result;

    }
    function get_transfer_commission($from_gateway,$to_gateway)
    {

        $query = $this->db->get_where('currency_fees',array('from_currency'=>$from_gateway,'to_currency'=>$to_gateway,'status'=>'active'));

        if($query->num_rows>0)
        {
            return $query->result();
        }
        else
        {
            return false; 
        }
    }
    function gatewayTOList()
    {
        $select = $this->db->query("SELECT b . * FROM `payment_gateways` AS a INNER JOIN currency_fees AS b ON a.gateway_name = b.from_currency");
        return $select->result();
    }


    function contact_support($data){ 
        $this->common_model->insertTableData('user_enquiry',$data);
        if($this->db->affected_rows()){
            return true;
        }else{
            return false;
        }
    }

    function order_status(){
            $result = $this->common_model->getTableData('order','', '', '', '', '', '', '5',array('datecreated'=>'desc'));
            return $result;
    }

    function order_status1(){
        if($this->session->userdata('customer_user_id')){
            $user_id = $this->session->userdata('customer_user_id');
            $result = $this->common_model->getTableData('order',array('user_id'=>$user_id),'', '', '', '', '', '5',array('datecreated'=>'desc'));
            return $result;
        }
        

    }

    function currencyList()
    {
        
        $query =  $this->common_model->getTableData("manage_gateway",array());
        if ($query->num_rows > 0) {
            return $query->row();
        } else {
            return false;
        }
    }


    function testimonials($data){
        $query =  $this->common_model->insertTableData("feedback",$data);
         $track = $data['order_track_id'];
        $result = $this->common_model->updateTableData('transaction',array('transaction_id'=>$track),array('feedback_status'=>1));
         if($this->db->affected_rows()){
            return true;
        } else {
            return false;
        }

    }

function check_tfa_siteconfig()
{
    $query = $this->common_model->getTableData('site_config',array());
    if($query->num_rows >= 1)
    {                   
        $row = $query->row();            
        return $row->TFA;           
    } 
    else
    {     
        return false;       
    }
}
function check_tfa_user1($id)
{
    $query = $this->common_model->getTableData('users',array('id'=>$id));
    if($query->num_rows >= 1)
    {                   
        $row = $query->row();            
        return $row->randcode;          
    } 
    else
    {     
        return false;       
    }
}
    function metatitle($metaurl)
    {
        $this->db->where('page_name',$metaurl);  
        $query=$this->db->get('meta_content'); 
        if($query->num_rows >= 1)
        {                   
        return $query->row();            
        }   
        else
        {      
        return false;       
        }
    }
    function verify_code($id,$rand)
    {          
        
        $re   = array('activation_code'=>$rand,'active'=>'2');
        $this->db->where('id',$id);
        $this->db->update('users',$re);
    }
    function verifycode($id)
    {
        $query = $this->db->get_where('users',array('activation_code'=>$id));
		if($query->num_rows() > 0){
        $row = $query->row();
        $ip_address   =  $_SERVER['REMOTE_ADDR']; 
        $browser_name =  $_SERVER['HTTP_USER_AGENT'];
        $re   = array('ip_address'=> $ip_address,
                      'browser_name'=>$browser_name,
                      'activation_code'=>'',
                      'active'=>1);
        $this->db->where('id',$row->id);
        $this->db->update('users',$re);
		return true;
		}else{
			return false;
		}
    }


/*-----------
Wallet Transaction*/
 function updatePaymentStatus($wallet_id,$amount)
    {
        
            //Add Tranactions
            $order_result   = $this->user_model->getOrderResult_ipn($wallet_id);
            $data1 = array('status'=>'Completed');
            $this->common_model->updateTableData("transaction",array('id'=>$order_result->id),$data1); 
            return true;
        
    }
    function updatePaymentStatus_cancel($order_id,$amount)
    {
        
            //Add Transactions
            $order_result   = $this->trans_model->getOrderResult_ipn($order_id);
            $data1 = array('status'=>'Pending');             
            $this->common_model->updateTableData("transaction",$data1,array('id'=>$order_result->id)); 
            return true;
      
    }

    function getOrderResult_ipn($id)
    {
        $this->db->where('id',$id);
        $query = $this->db->get('transaction');
        if($query->num_rows)
        {
            return $query->row();
        }
        else
        {
            return false;
        }
    }
/*-------------
Wallet Transaction End */


    
}
?>
