<?php
class Db_model extends CI_Model
{
    public $lpvalue = 0;
    public $csvalue = 0;
    function __construct(){
        parent::__construct();
    }

    public function gets($tbl_name)
    {
        return $this->db->query("SELECT * FROM " . $tbl_name)->row();
    }

    public function gets_result($tbl_name)
    {
        return $this->db->query("SELECT * FROM " . $tbl_name)->result();
    }

	public function gets_all()
	{
		return $this->db->query("SELECT * FROM user_info")->result();
	}

	public function gets_blocked_user()
	{
		return $this->db->query("SELECT * FROM user_info WHERE blockinfo=0")->result();

	}

	public function gets_user()
	{
		return $this->db->query("SELECT * FROM user_info WHERE blockinfo=1")->result();

	}

    public function delete_data($tbl_name, $id)
    {
        $this->db->where('ID', $id);
        $this->db->delete($tbl_name); 
    }
    public function checkjoinName($joinName)
    {
        return $this->db->get_where('postdata', array('id'=>$id))->row();
    }
    public function getinfowithjoinName($joinName)
    {
        return $this->db->get_where('postdata', array('joinName'=>$joinName))->result();
    }
    public function getuserinfo($userName)
    {
        return $this->db->get_where('users', array('nickname'=>$userName))->row();
    }
    public function getMembers($joinName)
    {
        $groupmember = $this->db->get_where('studygroup', array('group_name'=>$joinName))->row();
        if($groupmember != null)
        {
            $membernames = explode(",", $groupmember->memberName);
            $buffer = array();
            $tmpbuffer = array();

            foreach($membernames as $ent)
            {
                $userinfo = $this->db->get_where('users', array('nickname'=>$ent))->row();            
                $tmpbuffer['name'] = $ent;
                $tmpbuffer['image'] = $userinfo->photo;
                array_push($buffer, $tmpbuffer);
            }
            return $buffer;
        }
        return null;
    }

    //public function set_register_info($user_name, $user_email, $user_password, $user_phone)
    //{
    //    $save_data = array('name'=>$user_name, 'email'=>$user_email, 'password'=>$user_password, 'phone'=>$user_phone);
    //    $this->db->insert('admin_info', $save_data); 
    //}

    public function set_register_info($user_name, $user_password)
    {
        $save_data = array('name'=>$user_name, 'password'=>$user_password);
        $this->db->insert('admin_info', $save_data); 
    }

    public function getuser_info($userName, $userEmail)
    {
        return $this->db->get_where('users', array('nickname'=>$userName, 'email'=>$userEmail))->row();
    }

    public function transfer_money($u_id, $money)
    {
        $save_data = array('u_id'=>$u_id, 'u_money'=>$money);
        $this->db->insert('money_transfer', $save_data); 
    }

    public function set_freemoney($money)
    {
        $this->db->query("UPDATE admin_info SET freeCoins="."'".$money."'"); 
    }

    public function set_password($password)
    {
        $this->db->query("UPDATE admin_info SET password="."'".$password."'"); 
    }

    public function gets_freemoney()
    {
        return $this->db->query("SELECT * FROM admin_info")->row(); 
    }
    
    

    public function acceptNotify()
    {
        $this->db->query("UPDATE notify_table SET status=1");
    }




    public function get_all_notify($desc)
    {
        if($desc == 0)
        {
          return $this->db->query("SELECT * FROM notify_table")->result();
        }
        else
        {
            return $this->db->query("SELECT * FROM notify_table WHERE status=0")->result();
        }
    }

    public function get_back_money($u_id)
    {
        return $this->db->query("SELECT * from user_info where id=".$u_id)->row();
    }

    public function set_admin_money($id)
    {
        $this->db->query("delete from money_transfer where id=".$id);
    }

    public function get_data_byid($tblname, $id)
    {
        return $this->db->get_where($tblname, array('joinName'=>$joinName))->row();
    }

    public function get_admininfo($category)
    {
        return $this->db->get_where('admin_info', array('category'=>$category))->row();     
    }

    function get_login_info($username)
    {
        return $this->db->query("SELECT * FROM admin_info WHERE name='".$username."'")->row();
    }

    function get_client_info($userphone)
    {
        return $this->db->query("SELECT * FROM user_info WHERE phone='".$userphone."'")->row();
    }

    /**********************************************/
    public function insertTableData($tableName, $data = array())
    {
        $this->db->insert($tableName, $data);
        return $this->db->insert_id();
    }

    public function updateTableData($tableName = '', $where = array(), $data = array())
    {
        if ((is_array($where)) && (count($where) > 0)) {
            $this->db->where($where);
        }
        return $this->db->update($tableName, $data);
    }


	public function userBlock($id)
	{
		return $this->db->query("UPDATE user_info SET blockinfo=0 WHERE id=".$id);
	}

	public function userUnBlock($id)
	{
		return $this->db->query("UPDATE user_info SET blockinfo=1 WHERE id=".$id);
	}

	public function deleteUser($id)
	{
		return $this->db->query("DELETE FROM user_info WHERE id=".$id);

	}

    public function deleteNotify($id)
    {
        return $this->db->query("DELETE FROM notify_table WHERE id=".$id);
    }

	public function deleteRoom($id)
	{
		return $this->db->query("DELETE FROM room_info WHERE id=".$id);

	}

	public function addRoom($coin, $name, $winning_coin, $match_type)
	{
		return $this->db->query("INSERT INTO room_info (payoutcoin,room_name,winning_coin,matchtype) values (".$coin.",'".$name."',".$winning_coin.",".$match_type.")");

	}

    public function getTableData($tableName = '', $where = array(), $selectFields = '', $like = array(), $where_or = array(), $like_or = array(), $offset = '', $limit = '', $orderBy = array(), $groupBy = array())
    {
        // WHERE AND conditions
        if ((is_array($where)) && (count($where) > 0)) {
            $this->db->where($where);
        }
        // WHERE OR conditions
        if ((is_array($where_or)) && (count($where_or) > 0)) {
            $this->db->or_where($where_or);
        }
        //LIKE AND 
        if ((is_array($like)) && (count($like) > 0)) {
            $this->db->like($like);
        }
        //LIKE OR 
        if ((is_array($like_or)) && (count($like_or) > 0)) {
            $this->db->or_like($like_or);
        }
        //SELECT fields
        if ($selectFields != '') {
            $this->db->select($selectFields);
        }
        //Group By
        if (is_array($groupBy) && (count($groupBy) > 0)) {
            $this->db->group_by($groupBy[0]);
        }
        //Order By
        if (is_array($orderBy) && (count($orderBy) > 0)) {
            $this->db->order_by($orderBy[0], $orderBy[1]);
        }
        //OFFSET with LIMIT
        if($limit != '' && $offset != ''){
            $this->db->limit($limit, $offset);
        }
        // LIMIT
        if($limit != '' && $offset == ''){
            $this->db->limit($limit);
        }
        
        return $this->db->get($tableName);
    } 

    public function customQuery($query) {
        return $this->db->query($query);
    }      
}
?>
