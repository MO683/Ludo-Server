<?php
/**
 * Email_model Class
 * @package Osiz Technologies Pvt Ltd
 * @subpackage ConnectBTC
 * @category Model
 * @author Muthus
 * @version 1.0
 * @link http://osiztechnologies.com/
 * 
 */
 
 class Email_model extends CI_Model 
 {
	// Constructor function
	/*
	function Email_model() {
		parent::__construct();
	} */	
	
	
	public function __construct()
    {
        parent::__construct();        
    }  
    
	
	//Send email function 
	/**
	 * @access private
	 * @param array(),  
	 * @return email deliver report
	 * 
	 */
	 
	 function sendMail($to = '', $from_email = '', $from_name = '', $email_template = '', $special_vars = array(), $cc = '', $bcc = '', $type = 'html' ) {
	 	// Loads the email library
	 	$this->load->library(array('email'));
		// Email SMTP credentials
		$emailConfig = $this->db->where('id', 1)->get('site_settings')->row(); // Fetch from DB
		$admindetails = $this->db->where('id', 1)->get('users')->row(); // Fetch from DB		
		$smtp_host = $emailConfig->smtp_host; // SMTP host URL
		$smtp_port = $emailConfig->smtp_port; // SMTP port number
		$smtp_user = $emailConfig->smtp_email; // SMTP email address
		$smtp_pass = $emailConfig->smtp_password; // SMTP password	
		
		$special_vars['###FBLINK###'] = $emailConfig->facebook_url;
		$special_vars['###TWITTERLINK###'] = $emailConfig->twitter_url;
		$special_vars['###GOOGLELINK###'] = $emailConfig->google_url;
		$special_vars['###FBIMAGE###'] = base_url().'assets/images/facebook-logo-32.png';
		$special_vars['###TWITTERIMAGE###'] = base_url().'assets/images/twitter_online_social_media-32.png';
		$special_vars['###GOOGLEIMAGE###'] = base_url().'assets/images/40-google-plus-32.png';
		$special_vars['###PLANEIMAGE###'] = base_url().'assets/images/planes-997ae54560.png';
		$special_vars['###TERMSLINK###'] = site_url('terms-of-service');		
		$special_vars['###SITELOGO###'] =  getSiteLogo();
		
		if($from_email == '')
		$from_email = $admindetails->email;
		if($from_name == '')
		$from_name = $admindetails->first_name.' '.$admindetails->last_name;
		$this->email->clear();
		// Email config
		$config = array(
			'protocol' => 'smtp',
			'smtp_host' => $smtp_host,
			'smtp_port' => $smtp_port,
			'smtp_user' => trim($smtp_user),
			'smtp_pass' => trim($smtp_pass),
			'mailtype' => $type,
			'charset' => 'utf-8'
		);
		$config['crlf'] = "\r\n";
		$config['newline'] = "\r\n";
		$config['priority'] = 1;
		$config['smtp_timeout'] = '7';
		// Email config initialize
		$this->email->initialize($config);
		//$this->email->set_newline("\r\n");

		if ( ! empty($smtp_host) && ! empty($smtp_port) && ! empty($smtp_user) && ! empty($smtp_pass)) {
	    if(is_numeric($email_template)	)	
	    $emailTemplate = $this->db->where('id', $email_template)->get('email_template');
        else
		$emailTemplate = $this->db->where('name', $email_template)->get('email_template');
		
			if ($emailTemplate->num_rows() > 0) {
				$emailTemplate = $emailTemplate->row();
				// Subject
				$subject = strtr($emailTemplate->subject, $special_vars);
				// message content
				$message = strtr($emailTemplate->template, $special_vars);
				

				//Working Code
				$this->email->set_newline("\r\n"); 
				$this->email->to($to);
        		$this->email->from($from_email,$from_name);
				if ($cc != '') {
				$this->email->cc($cc);
				}
				if ($bcc != '') {	
				$this->email->bcc($bcc);
				} 
  				$this->email->subject($subject);
  				$this->email->message($message);
			// Prepare to email send	
  				//print_r($config); print_r($this->email); exit;

			if ( ! $this->email->send()) { // Mail not sent
				//echo $this->email->print_debugger();
				// exit;
				//if($email_template == 'New Device Login' || $email_template ==  'Account Verification' || $email_template == 'Failed Login' || $email_template == 'Failed Login' || $email_template == 'Testimonial Approval' || $email_template == 'Testimonial FREE Passport' || $email_template == 'Purchase Passport' 
				//|| $email_template == 'connectBTC Bank PH Matched' 
				
				return false;
			} else { // mail sent
			
			    if(in_array($emailTemplate->id, array(1,16,17,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39))){
				 $messageData = array(
				  'user_id'=>((isset( $_POST['user_id']) &&  $_POST['user_id'] != '')? $_POST['user_id']:'0'),
				  'email'=>$to,
				  'label'=>$emailTemplate->category,
				  'from_user_id'=>'1',
				  'name'=>'',
				  'created_at'=>date('Y-m-d H:i:s'),
				  'message'=>$subject,
				  'template'=>$message,
				  );
				  $this->common_model->insertTableData('messages',$messageData);
			    }	

				return true;
			} 
			

	return true;

			} else {
				exit('Email template not configured please contact support team');
			}	 
		} else {
			exit('SMTP not configured please contact support team');
		}
		
	 }



 }

/**
 * End of the file email_model.php
 * Location: ./application/models/email_model.php
 */ 
