<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'admin';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['dashboard'] = 'admin/dashboard';
$route['signup'] = 'admin/signup';
$route['signin'] = 'admin/index';
$route['signout'] = 'admin/signout';
$route['user-list'] = 'admin/userlist';
$route['user-block/(:any)'] = 'admin/user_block/$1';
$route['user-blocked-list'] = 'admin/userblockedlist';
$route['user-unblock/(:any)'] = 'admin/user_unblock/$1';
$route['user-delete/(:any)'] = 'admin/userdelete/$1';
$route['user-search'] = 'admin/user_search';
$route['deposit-history/(:any)'] = 'admin/deposit_history/$1';
$route['withdraw-history/(:any)'] = 'admin/withdraw_history/$1';
$route['game-stats/(:any)'] = 'admin/game_stats/$1';
$route['user-money-segment'] = 'admin/user_money_segment';
$route['user-money-transfer/(:any)'] = 'admin/user_money_transfer/$1';
$route['user-money-getback/(:any)'] = 'admin/user_money_getback/$1';
$route['system-commission'] = 'admin/system_commission';
$route['system-calculation'] = 'admin/system_calculation';
$route['game-event'] = 'admin/game_event';
$route['game-jackpot'] = 'admin/game_jackpot';
$route['game-log'] = 'admin/game_log';
$route['game-bots'] = 'admin/game_bots';
$route['manage-room'] = 'admin/manage_room';
$route['admin-wallet'] = 'admin/manage_wallte';
$route['admin-money-transfer/(:any)'] = 'admin/admin_money_transfer/$1';
$route['room-delete/(:any)'] = 'admin/roomdelete/$1';
$route['add-room'] = 'admin/addroom';
$route['notification'] = 'admin/notification';
$route['notify-delete/(:any)'] = 'admin/notifydelete/$1';
$route['notify-accept'] = 'admin/notifyAccept';
$route['buycoin/(:any)'] = 'admin/buycoin/$1';
$route['userlogin/(:any)'] = 'admin/userLogin/$1';
$route['refercoinsetting'] = 'admin/refercoinsetting';
$route['freecoins_transfer'] = 'admin/freecoins_transfer';
$route['changepassword'] = 'admin/changepassword';
$route['savepassword'] = 'admin/savepassword';

