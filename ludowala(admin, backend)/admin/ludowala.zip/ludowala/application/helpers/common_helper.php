<?php
/**
 * Common Helper
 * @package Osiz Technologies Pvt Ltd
 * @subpackage connectBTC
 * @category Helpers
 * @author Muthus
 * @version 1.0
 * @link http://osiztechnologies.com/
 * 
 */
 // Administrator URL
 function admin_url()
 {
 	return base_url() . 'upravitelj/';
 }
 function site_admin_url($url)
 {
 	return site_url('upravitelj/'.$url);
 }
 // User URL
 function user_url()
 {
 	return base_url() . 'users/';
 }
 // CSS URL
 function css_url()
 {
 	return base_url() . 'assets/css/';
 }
 // JavaScript URL
 function js_url()
 {
 	return base_url() . 'assets/js/';
 }
 // Uploads URL
 function uploads_url()
 {
 	return base_url() . 'uploads/';
 }
 // Admin panel source URL
 function admin_source() 
 {
 	return base_url() . 'admin_panel/';	
 } 
 // Admin URL redirect
 function admin_redirect($url, $refresh = 'refresh') {
 	redirect('upravitelj/'.$url, $refresh);
 }
  // User URL redirect
 function user_redirect($url, $refresh = 'refresh') {
 	redirect('users/'.$url, $refresh);
 }
 // Site name
 function getSiteName() {
 	$ci =& get_instance();
	$name = $ci->db->where('id', 1)->get('site_settings')->row()->site_name;
	if ($name) {
		return $name;
	} else {
		return 'Osiz Technologies Pvt Ltd';	
	}
 }
 // Site logo
 function getSiteLogoEmail() {
 	$ci =& get_instance();
	//$logo = $ci->db->where('id', 1)->get('site_settings')->row()->site_logo;	
		return base_url() . 'assets/img/logo-foot.png?123';	
	//}
 }
 
  // Site logo
 function getSiteLogo() {
 	$ci =& get_instance();
	$logo = $ci->db->where('id', 1)->get('site_settings')->row()->site_logo;
	if ($logo) {
		return base_url() . 'logo/'.$logo.'?123';
	} else {
		return base_url() . 'logo/logo.png?123';	
	}
 }
 
 
 // User profile picture
 function getProfilePicture($id = '', $start='') {
 	$ci =& get_instance();
 	if ($id == '') {
			return base_url() . 'assets/images/h_userbig.png';
 	} else {
 		$profilePicture = $ci->db->where('id',$id)->get('users');
		if ($profilePicture->num_rows() > 0) {
			$profilePicture = $profilePicture->row()->profile_picture;
			if ($profilePicture != '') {
				return (is_file(uploads_url() . 'user/' . $start.$profilePicture)?uploads_url() . 'user/' . $start.$profilePicture:uploads_url() . 'user/' . $profilePicture);
			} else {
			return base_url() . 'assets/images/h_userbig.png';
			}	
		} else {
			return base_url() . 'assets/images/h_userbig.png';
		}
 	}
 }
 
  // User verification documents
 function getdocumentPicture($name='') { 	
	return uploads_url() . 'user/documents/' . $name;
 }
// User details
 function getUserDetails($id) {
 	$ci =& get_instance();
	$userDetails = $ci->db->where('id', $id)->get('users');
	if ($userDetails->num_rows() > 0) {
		return $userDetails->row();
	} else {
		return FALSE;
	}
 } 
// Get banner image
function getBannerImage($id) {
	$ci =& get_instance();
	$bannerDetails = $ci->db->where('id', $id)->get('banners');
	if ($bannerDetails->num_rows() > 0) {
		$image = $bannerDetails->row()->image;
		return uploads_url() . 'banners/' . $image;
	} else {
		return uploads_url() . 'default/noimage.png'; 
	}
}
//Get Follow us details
 function getfollowus() {
 	$ci =& get_instance();
	$content = $ci->db->where('link', 'get_in_touch')->get('cms')->row()->content;
	if ($content) {
		return $content;
	} else {
		return 'Osiz Technologies Pvt Ltd';	
	}
 }
 
 //get extension of file
 function getExtension($type){
	 switch (strtolower($type)) {        
		case 'image/jpg':
			$ext = 'jpg';
		break;
		
		case 'image/jpeg':
			$ext = 'jpg';
		break;

		case 'image/png':
			$ext = 'png';
		break;

		case 'image/gif':
			$ext = 'gif';
		break;
		
		default:
		$ext = 'gif';
		break;
   }
   return $ext;
 }
 
 //get value of specific curreny
 function googlecurrencyconvert($amount,$from_Currency,$to_Currency){
	$amount = urlencode($amount);
	$from_Currency = urlencode($from_Currency);
	$to_Currency = urlencode($to_Currency);
	$get = file_get_contents("https://www.google.com/finance/converter?a=$amount&from=$from_Currency&to=$to_Currency");
	$get = explode("<span class=bld>",$get);
	$get = explode("</span>",$get[1]);
	return $converted_amount = preg_replace("/[^0-9.]/", null, $get[0]);
}


//format to decimal places as below
function to_decimal($value, $places=8){
	if(trim($value)=='')
	return 0;
	else if((float)$value==0)
	return 0;
	if((float)$value==(int)$value)
	return (int)$value;   
	else{		
		$value = number_format($value, $places, '.','');
		$value1 = $value;					
		if(substr($value,-1) == '0')
		$value = substr($value,0,strlen($value)-1);
		if(substr($value,-1) == '0')
		$value = substr($value,0,strlen($value)-1);
		if(substr($value,-1) == '0')
		$value = substr($value,0,strlen($value)-1);
		if(substr($value,-1) == '0')
		$value = substr($value,0,strlen($value)-1);
		if(substr($value,-1) == '0')
		$value = substr($value,0,strlen($value)-1);
		if(substr($value,-1) == '0')
		$value = substr($value,0,strlen($value)-1);		
		if(substr($value,-1) == '0')
		$value = substr($value,0,strlen($value)-1);			
		return $value;
	}
}


//create skuug url from string
function slugify($text)
{
  // replace non letter or digits by -
  $text = preg_replace('~[^\pL\d]+~u', '-', $text);

  // transliterate
  $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);

  // remove unwanted characters
  $text = preg_replace('~[^-\w]+~', '', $text);

  // trim
  $text = trim($text, '-');

  // remove duplicate -
  $text = preg_replace('~-+~', '-', $text);

  // lowercase
  $text = strtolower($text);

  if (empty($text)) {
    return 'n-a';
  }

  return $text;
}


function getOS() { 

   $user_agent = $_SERVER['HTTP_USER_AGENT'];

    $os_platform    =   "Unknown OS Platform";

    $os_array       =   array(
                            '/windows nt 10/i'     =>  'Windows 10',
                            '/windows nt 6.3/i'     =>  'Windows 8.1',
                            '/windows nt 6.2/i'     =>  'Windows 8',
                            '/windows nt 6.1/i'     =>  'Windows 7',
                            '/windows nt 6.0/i'     =>  'Windows Vista',
                            '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                            '/windows nt 5.1/i'     =>  'Windows XP',
                            '/windows xp/i'         =>  'Windows XP',
                            '/windows nt 5.0/i'     =>  'Windows 2000',
                            '/windows me/i'         =>  'Windows ME',
                            '/win98/i'              =>  'Windows 98',
                            '/win95/i'              =>  'Windows 95',
                            '/win16/i'              =>  'Windows 3.11',
                            '/macintosh|mac os x/i' =>  'Mac OS X',
                            '/mac_powerpc/i'        =>  'Mac OS 9',
                            '/linux/i'              =>  'Linux',
                            '/ubuntu/i'             =>  'Ubuntu',
                            '/iphone/i'             =>  'iPhone',
                            '/ipod/i'               =>  'iPod',
                            '/ipad/i'               =>  'iPad',
                            '/android/i'            =>  'Android',
                            '/blackberry/i'         =>  'BlackBerry',
                            '/webos/i'              =>  'Mobile'
                        );

    foreach ($os_array as $regex => $value) { 

        if (preg_match($regex, $user_agent)) {
            $os_platform    =   $value;
        }

    }   

    return $os_platform;

}

function getBrowser() {

    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    $browser        =   "Unknown Browser";

    $browser_array  =   array(
                            '/msie/i'       =>  'Internet Explorer',
                            '/firefox/i'    =>  'Firefox',
                            '/safari/i'     =>  'Safari',
                            '/chrome/i'     =>  'Chrome',
                            '/edge/i'       =>  'Edge',
                            '/opera/i'      =>  'Opera',
                            '/netscape/i'   =>  'Netscape',
                            '/maxthon/i'    =>  'Maxthon',
                            '/konqueror/i'  =>  'Konqueror',
                            '/mobile/i'     =>  'Handheld Browser'
                        );

    foreach ($browser_array as $regex => $value) { 

        if (preg_match($regex, $user_agent)) {
            $browser    =   $value;
        }

    }

    return $browser;

}


//show site image
function show_site_image($image){
	if(trim($image) != ''){
		if (file_exists('uploads/sites/361x210_'.$image)) 
		return base_url().'uploads/sites/361x210_'.$image;
		else
		return base_url().'uploads/sites/'.$image;
	}else
	return base_url().'assets/images/site_image.jpg';
	
}
//show pdf thumb image
function show_pdf_thumb($image){
	if(trim($image) != ''){
		if (file_exists('uploads/pdf/thumb/361x210_'.$image)) 
		return base_url().'uploads/pdf/thumb/361x210_'.$image;
		else
		return base_url().'uploads/pdf/thumb/'.$image;
	}else
	return base_url().'assets/images/pdf_thumb.jpg';	
}

//show video thumb image
function show_video_thumb($image){
	if(trim($image) != ''){
		if (file_exists('uploads/video/thumb/360x360_'.$image)) 
		return base_url().'uploads/video/thumb/360x360_'.$image;
		else
		return base_url().'uploads/video/thumb/'.$image;
	}else
	return base_url().'assets/images/pdf_thumb.jpg';	
}
//show level image
function show_level_image($image){
	if(trim($image) != ''){		
		return base_url().'uploads/levels/'.$image;
	}else
	return base_url().'assets/images/level_image.png';	
}
//show user profile image full
function show_profile_image($image){
	if(trim($image) != ''){	
		if (file_exists('uploads/user/137x137_'.$image)) 
		return base_url().'uploads/user/137x137_'.$image;
		else	
		return base_url().'uploads/user/'.$image;
	}else
	return base_url().'assets/images/user1.png';	
}
//show user profile image full
function show_profile_image_thumb($image){
	if(trim($image) != ''){	
		if (file_exists('uploads/user/45x45_'.$image)) 
		return base_url().'uploads/user/45x45_'.$image;
		else	
		return base_url().'uploads/user/'.$image;
	}else
	return base_url().'assets/images/user1.png';	
}


function getVimeoInfo($vimeo)
{
    $url = parse_url($vimeo);
    if($url['host'] !== 'vimeo.com' &&
            $url['host'] !== 'www.vimeo.com')
        return false;
   if (preg_match('~^http://(?:www\.)?vimeo\.com/(?:clip:)?(\d+)~', $vimeo, $match)){
       $id = $match[1];
   }elseif (preg_match('~^https://(?:www\.)?vimeo\.com/(?:clip:)?(\d+)~', $vimeo, $match)){
       $id = $match[1];
   }else{
       $id = substr($vimeo,10,strlen($vimeo));
   }

   $ch = curl_init();
   curl_setopt($ch, CURLOPT_URL, "https://vimeo.com/api/v2/video/192733922.xml");
   curl_setopt($ch, CURLOPT_HEADER, 0);
   curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
   curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
   curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
   curl_setopt($ch, CURLOPT_TIMEOUT, 10);
   $httpCode = curl_getinfo($ch , CURLINFO_HTTP_CODE);
   $output = curl_exec($ch);   
   $xml = simplexml_load_string($output, "SimpleXMLElement", LIBXML_NOCDATA);
   $json = json_encode($xml);
   $content = json_decode($json,TRUE);
   return $content;
}

	
function getYoukuInfo($link)
{
   if (preg_match('/id_(\w+)/', $link, $match)){	   
       $id = $match[1];
   }else{
      return false;
   }

    $url="https://openapi.youku.com/v2/videos/show_basic.json?video_id=".$id."&client_id=your_api_key";
	$data=file_get_contents($url);
	$json=json_decode($data,true);
	return $json;
}


//show video thumb image
function show_testimonial_thumb($image){
	if(trim($image) != ''){
		return base_url().'uploads/testimonial/'.$image;
	}else
	return base_url().'assets/images/pdf_thumb.jpg';	
}

//Simple encrypt
function simple_encrypt($str){
	$key1 = 'MN5DzDpD5SBti1m7x';
	$key2 = 'U3iJrMu8PJhs7fxfrei';
	return urlencode(base64_encode($key1.$str.$key2));
}
//Simple decypt
function simple_decrypt($str){
	$key1 = 'MN5DzDpD5SBti1m7x';
	$key2 = 'U3iJrMu8PJhs7fxfrei';
	$decodedata =  base64_decode(urldecode($str));
	return str_replace(array($key1,$key2), '', $decodedata);
}

function positionname($pos){
	$positions = array('0'=>'', '1'=>'Left','2'=>'Center','3'=>'Right');
	return $positions[$pos];
}

//calculate difference between two dates in days
function diff_in_days($date1,$date2=''){
	if($date2 != '')
	$time2 = strtotime($date2);
	else
	$time2 = time();
	
	$time1 = strtotime($date1);	
	$datediff = $time2 - $time1;
    return floor($datediff / (60 * 60 * 24));	
}

//Simple encrypt
function simple_encrypt_message($str){
	$key1 = 'RDCCpD4dv85dvd5v95dfD451';
	$key2 = 'GS55SDFF55SDS9598SFS855asdSCF';
	return urlencode(base64_encode($key1.$str.$key2));
}
//Simple decypt
function simple_decrypt_message($str){
	$key1 = 'RDCCpD4dv85dvd5v95dfD451';
	$key2 = 'GS55SDFF55SDS9598SFS855asdSCF';
	$decodedata =  base64_decode(urldecode($str));
	return str_replace(array($key1,$key2), '', $decodedata);
}
