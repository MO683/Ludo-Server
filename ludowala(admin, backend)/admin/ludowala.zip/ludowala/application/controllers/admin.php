<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Admin extends CI_Controller {

	public function __construct(){
        parent::__construct();

        $this->load->helper('url');
		$this->load->model('db_model');	      
		
		$this->data = $this->db_model->gets_result("user_info");

		
	}
    public function index()
	{	
        if ($this->input->post())
        {
            $user_name = trim($this->input->post('user_name'));
            $user_password = trim($this->input->post('user_password'));
            if (($user_name == '') || ($user_password == ''))
            {
                $this->session->set_flashdata('message', '* Please input correct information. *');
            }
            else
            {
                $userinfo = $this->db_model->get_login_info($this->input->post('user_name'));
                if ($userinfo == null)
                {
                    $this->session->set_flashdata('message', '* Please input correct information. *');
                }
                else
                {
                    if ($userinfo->password != $user_password)
                    {
                        $this->session->set_flashdata('message', '* Please input correct information. *');
                    }
                    else
                    {
                        $this->session->set_userdata('is_login', true);
                        $this->session->set_userdata('userinfo', $userinfo);
                        redirect('user-list');
                    }
                }
            }            
        }

        $this->load->view('index');
    }


    public function userLogin($money)
    {
        if ($this->input->post())
        {
            $user_phone = (string)trim($this->input->post('user_phone'));
            $user_phone = "91".$user_phone;
            $user_password = trim($this->input->post('user_password'));
            if (($user_phone == '') || ($user_password == ''))
            {
                $this->session->set_flashdata('message', '* Please input correct information. *');
            }
            else
            {
                $userinfo = $this->db_model->get_client_info($user_phone);
                if ($userinfo == null)
                {
                    $this->session->set_flashdata('message', '* Please input correct information. *');
                }
                else
                {
                    if ($userinfo->password != $user_password)
                    {
                        $this->session->set_flashdata('message', '* Please input correct information. *');
                    }
                    else
                    {
                        $this->session->set_userdata('user_login', true);
                        $this->session->set_userdata('clientinfo', $userinfo);
                        redirect('buycoin/'.$money);
                    }
                }
            }            
        }
        
        $this->load->view('usersignin', array('money'=>$money));
    }

    public function signout()
    {
        $this->session->set_userdata('is_login', false);
        redirect('signin');
    }

    public function signup()
    {        
        if ($this->input->post())
        {
            $user_name = trim($this->input->post('user_name'));
            $user_email = trim($this->input->post('user_email'));
            $user_password = trim($this->input->post('user_password'));
            $user_phone = trim($this->input->post('user_phone'));

            if (($user_name == '') || ($user_email == '') || ($user_password == '') || ($user_phone == ''))
            {
                $this->session->set_flashdata('message', '* Please input correct information. *');
            }
            else
            {        
                $userinfo = $this->db_model->get_login_info($user_name);
                if ($userinfo == null)         
                {
                    $userinfo = $this->db_model->set_register_info($user_name, $user_email, $user_password, $user_phone);
                    redirect('signin');
                }   
                else
                {
                    $this->session->set_flashdata('message', '* Please input correct information. *');
                }                
            }
        }

        $this->load->view('register');
    }

    public function dashboard()
    {
        if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userdata = $this->session->userdata('userinfo');
        $data['user_name'] = $userdata->userid;
        $notify_alert = $this->db_model->get_all_notify(1);


        $this->load->view('dashboard');
        $this->load->view('sidebar');
        $this->load->view('topbar', array('user_name'=>$userinfo->name, 'notify_data'=>$notify_alert));
        $this->load->view('statistic');
        $this->load->view('footer');
    }

    public function userlist()
    {
        if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');

        $data['user_name'] = $userinfo->name;

        $userdata = $this->db_model->gets_user();
        $notify_alert = $this->db_model->get_all_notify(1);

        $this->load->view('dashboard');
        $this->load->view('sidebar');
        $this->load->view('topbar', array('user_name'=>$userinfo->name, 'notify_data'=>$notify_alert));
        $this->load->view('userlist', array('bodydata'=>$userdata));
        $this->load->view('footer');
    }    
    
    public function user_block($u_id)
    {
        if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');
        $data = array();
        $data['user_name'] = $userinfo->name;

        //$this->adminapi->user_block($u_id);
		$this->db_model->userBlock($u_id);

        redirect('user-list');
    }

    public function user_search()
    {
        if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');
        $data = array();
        $data['user_name'] = $userinfo->name;

        $userdata = $this->adminapi->userlist(0);
        $notify_alert = $this->db_model->get_all_notify(1);

        $this->load->view('dashboard');
        $this->load->view('sidebar');
        $this->load->view('topbar', array('user_name'=>$userinfo->name, 'notify_data'=>$notify_alert));
        $this->load->view('searchuser', array('bodydata'=>$userdata['messages']));
        $this->load->view('footer');
    }

    public function userblockedlist()
    {
        if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');
		$data = array();
        $data['user_name'] = $userinfo->name;

        $userdata = $this->db_model->gets_blocked_user();
        $notify_alert = $this->db_model->get_all_notify(1);

        $this->load->view('dashboard');
        $this->load->view('sidebar');
        $this->load->view('topbar', array('user_name'=>$userinfo->name, 'notify_data'=>$notify_alert));
        $this->load->view('blockedusers', array('bodydata'=>$userdata));
        $this->load->view('footer');
    }

    public function user_unblock($u_id)
    {
        if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');
        $data = array();
        $data['user_name'] = $userinfo->name;

        $this->db_model->userUnBlock($u_id);
        redirect('user-blocked-list');
    }

    public function userdelete($u_id)
    {
        if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');
        $data = array();
        $data['user_name'] = $userinfo->name;

        $this->db_model->deleteUser($u_id);
        redirect('user-blocked-list');
    }

    public function notifydelete($id)
    {
        if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');
        $data = array();
        $data['user_name'] = $userinfo->name;

        $this->db_model->deleteNotify($id);
        
        redirect('notification');
    }

	public function roomdelete($u_id)
    {
        if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');
        $data = array();
        $data['user_name'] = $userinfo->name;

        $this->db_model->deleteRoom($u_id);
        redirect('manage-room');
    }


	public function addroom()
	{
		if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');
        $notify_alert = $this->db_model->get_all_notify(1);
        $data = array();
        $data['user_name'] = $userinfo->name;

        if ($this->input->post())
        {
            $money = trim($this->input->post('coin'));
            $name = trim($this->input->post('room_name'));
            $wincoin = trim($this->input->post('wincoin'));
            $matchtype = trim($this->input->post('matchtype'));
            if (($money == '') || ($name == '') || ($wincoin == '') ||($matchtype == ''))
            {
                $this->session->set_flashdata('message', 'Please input correct Type.');
            }
            else
            {
                $retdata = $this->db_model->addRoom($money, $name, $wincoin, $matchtype);
                if ($retdata == TRUE)
                    $this->session->set_flashdata('message', 'To transfer is success.');
                else
                {
                    $this->session->set_flashdata('message', 'To transfer is failed.');
                }
            }            
        }       

        $this->load->view('dashboard');
        $this->load->view('sidebar');
        $this->load->view('topbar', array('user_name'=>$userinfo->name, 'notify_data'=>$notify_alert));
        $this->load->view('addroom');
        $this->load->view('footer');
	}


    public function notifyAccept()
    {
        if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');
        $data = array();
        $data['user_name'] = $userinfo->name;

        $this->db_model->acceptNotify();
        redirect();
    }

    public function notification()
    {

        if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');
        $data = array();
        $data['user_name'] = $userinfo->name;
        $notify_data = $this->db_model->get_all_notify(0);
        $notify_alert = $this->db_model->get_all_notify(1);

        $this->load->view('dashboard');
        $this->load->view('sidebar');
        $this->load->view('topbar', array('user_name'=>$userinfo->name, 'notify_data'=>$notify_alert));
        $this->load->view('notification', array('bodydata'=>$notify_data));
        $this->load->view('footer');
    }




    public function deposit_history($u_id)
    {
        if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');
        $data = array();
        $data['user_name'] = $userinfo->name;

        $userdata = $this->adminapi->userlist(1);
        $notify_alert = $this->db_model->get_all_notify(1);

        $this->load->view('dashboard');
        $this->load->view('sidebar');
        $this->load->view('topbar', array('user_name'=>$userinfo->name, 'notify_data'=>$notify_alert));
        $this->load->view('deposithistory', array('username'=>$data['user_name']));
        $this->load->view('footer');
    }

    public function withdraw_history($u_id)
    {
        if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');
        $data = array();
        $data['user_name'] = $userinfo->name;

        $userdata = $this->adminapi->userlist(1);

        $this->load->view('dashboard');
        $this->load->view('sidebar');
        $this->load->view('topbar', array('user_name'=>$userinfo->name, 'notify_data'=>$notify_alert));
        $this->load->view('withdrawhistory', array('username'=>$data['user_name']));
        $this->load->view('footer');
    }

    public function game_stats($flag)
    {
        if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');
        $data = array();
        $data['user_name'] = $userinfo->name;

        $userdata = [];
        $retdata = $this->adminapi->game_stats($flag);
        $notify_alert = $this->db_model->get_all_notify(1);
        
        if ($retdata['result'] == "failed")
            $userdata = [];
        else
            $userdata = $retdata['users'];

        $this->load->view('dashboard');
        $this->load->view('sidebar');
        $this->load->view('topbar', array('user_name'=>$userinfo->name, 'notify_data'=>$notify_alert));
        $this->load->view('gamestats', array('bodydata'=>$userdata, 'flag'=>$flag));
        $this->load->view('footer');
    }

    public function user_money_segment()
    {
        if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');
		$data = array();
        $data['user_name'] = $userinfo->name;

		$usermoney = $this->db_model->gets_result("user_info");
        $notify_alert = $this->db_model->get_all_notify(1);

        $this->load->view('dashboard');
        $this->load->view('sidebar');
        $this->load->view('topbar', array('user_name'=>$userinfo->name, 'notify_data'=>$notify_alert));
        $this->load->view('usermoneysegment', array('bodydata'=>$usermoney));
        $this->load->view('footer');
    }


    public function buycoin($money)
    {
        if (!$this->session->userdata('user_login')) {
            redirect('userlogin/'.$money);
        }

        $userinfo = $this->session->userdata('clientinfo');

        $this->load->view('buycoin', array('money'=>$money, 'userinfo'=>$userinfo));
    }

    public function user_money_transfer($u_id)
    {
        if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');
        $data = array();
        $data['user_name'] = $userinfo->name;
        $notify_alert = $this->db_model->get_all_notify(1);

        if ($this->input->post())
        {
            $money = trim($this->input->post('money'));
            $u_id = trim($this->input->post('u_id'));
            if (($money == ''))
            {
                $this->session->set_flashdata('message', 'Please input correct money.');
            }
            else
            {
                $this->db_model->transfer_money($u_id, $money);
                $retdata = $this->adminapi->transfermoney($u_id, $money);
                if ($retdata['result'] == 'success')
                    $this->session->set_flashdata('message', 'To transfer is success.');
                else
                {
                    $this->session->set_flashdata('message', 'To transfer is failed.');
                }
            }            
        }       

        $this->load->view('dashboard');
        $this->load->view('sidebar');
        $this->load->view('topbar', array('user_name'=>$userinfo->name, 'notify_data'=>$notify_alert));
        $this->load->view('usermoneytransfer', array('u_id'=>$u_id));
        $this->load->view('footer');
    }

    public function freecoins_transfer()
    {
        if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');
        $data = array();
        $data['user_name'] = $userinfo->name;
        $notify_alert = $this->db_model->get_all_notify(1);

        if ($this->input->post())
        {
            $money = trim($this->input->post('money'));            
           
            if (($money == 0))
            {
                $this->session->set_flashdata('message', 'Please input correct money.');
            }
            else
            {
               $this->db_model->set_freemoney($money);              
               $this->session->set_flashdata('message', 'Saved Sucessfully.');
            }            
        }       

        $userdata =  $this->db_model->gets_freemoney();

        $this->load->view('dashboard');
        $this->load->view('sidebar');
        $this->load->view('topbar', array('user_name'=>$userinfo->name, 'notify_data'=>$notify_alert));
        $this->load->view('refercoinsetting', array('bodydata'=>$userdata));
        $this->load->view('footer');
    }
    
    public function refercoinsetting()
    {
        if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');

        $data['user_name'] = $userinfo->name;

        $money = $this->db_model->gets_freemoney();
        $notify_alert = $this->db_model->get_all_notify(1);




        $this->load->view('dashboard');
        $this->load->view('sidebar');
        $this->load->view('topbar', array('user_name'=>$userinfo->name, 'notify_data'=>$notify_alert));
        $this->load->view('refercoinsetting', array('bodydata'=>$money));
        $this->load->view('footer');
    }    

    public function changepassword()
    {
        if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');

        $data['user_name'] = $userinfo->name;

        if ($this->input->post())
        {
            $password = trim($this->input->post('password'));            
           
            if (($password == 0))
            {
                $this->session->set_flashdata('message', 'Please Input Admin Password.');
            }
            else
            {
               $this->db_model->set_password($password);              
               $this->session->set_flashdata('message', 'Saved Sucessfully.');
            }            
        }
        
        $notify_alert = $this->db_model->get_all_notify(1);

        $money = $this->db_model->gets_freemoney();

        
        $this->load->view('dashboard');
        $this->load->view('sidebar');
        $this->load->view('topbar', array('user_name'=>$userinfo->name, 'notify_data'=>$notify_alert));
        $this->load->view('changepassword',  array('bodydata'=>$money));
        $this->load->view('footer');
    }    

     public function savepassword()
    {
        if ( !$this->session->userdata('is_login') )
            redirect('signin');        

        if ($this->input->post())
        {
            $password = trim($this->input->post('password'));                      
            $this->db_model->set_password($password);        
        }
        
        redirect('signout');
    }    

    public function user_money_getback($u_id)
    {
        if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');
        $data = array();
        $data['user_name'] = $userinfo->name;

        $moneydata = $this->db_model->get_back_money($u_id);
        if ($moneydata != null)
        {
            $record_id = $moneydata->money;
            $this->db_model->set_admin_money($record_id);
            
            $retdata = $this->adminapi->getbackmoney($u_id, $moneydata->u_money);
            if ($retdata['result'] == 'success')
                $this->session->set_flashdata('message', 'To transfer is success.');
            else
            {
                $this->session->set_flashdata('message', 'To transfer is failed.');
            }     
        }      
        
        redirect('user-money-segment');
    }

	public function manage_room()
	{
		if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');
		$data = array();
        $data['user_name'] = $userinfo->name;
        $notify_alert = $this->db_model->get_all_notify(1);

		$usermoney = $this->db_model->gets_result("room_info");

        $this->load->view('dashboard');
        $this->load->view('sidebar');
        $this->load->view('topbar', array('user_name'=>$userinfo->name, 'notify_data'=>$notify_alert));
        $this->load->view('roommanagement', array('bodydata'=>$usermoney));
        $this->load->view('footer');
	}


	public function manage_wallte()
	{
		if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');
		$data = array();
        $data['user_name'] = $userinfo->name;
        $notify_alert = $this->db_model->get_all_notify(1);

		$userdata = $this->db_model->gets_result("admin_wallet");

        $this->load->view('dashboard');
        $this->load->view('sidebar');
        $this->load->view('topbar', array('user_name'=>$userinfo->name, 'notify_data'=>$notify_alert));
        $this->load->view('showadminwallet', array('bodydata'=>$userdata));
        $this->load->view('footer');
    }

   

	public function admin_money_transfer($u_id)
    {
        if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');
        $data = array();
        $data['user_name'] = $userinfo->name;
        $notify_alert = $this->db_model->get_all_notify(1);

        if ($this->input->post())
        {
            $money = trim($this->input->post('money'));
            $u_id = trim($this->input->post('u_id'));
            if (($money == ''))
            {
                $this->session->set_flashdata('message', 'Please input correct money.');
            }
            else
            {
                $this->db_model->transfer_money($u_id, $money);
                $retdata = $this->adminapi->transfermoney($u_id, $money);
                if ($retdata['result'] == 'success')
                    $this->session->set_flashdata('message', 'To transfer is success.');
                else
                {
                    $this->session->set_flashdata('message', 'To transfer is failed.');
                }
            }            
        }       

        $this->load->view('dashboard');
        $this->load->view('sidebar');
        $this->load->view('topbar', array('user_name'=>$userinfo->name, 'notify_data'=>$notify_alert));
        $this->load->view('adminmoneytransfer', array('u_id'=>$u_id));
        $this->load->view('footer');
    }


    public function system_commission()
    {
        if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');
        $data = array();
        $data['user_name'] = $userinfo->name;

        if ($this->input->post())
        {
            $jackpot_rate = trim($this->input->post('jackpot_rate'));
            $rank_rate = trim($this->input->post('rank_rate'));
            if (($jackpot_rate == '') || ($rank_rate == ''))
            {
                $this->session->set_flashdata('message', 'Please input correct money.');
            }
            else
            {
                $retdata = $this->adminapi->setcommission($jackpot_rate, $rank_rate);
                if ($retdata['result'] == 'success')
                    $this->session->set_flashdata('message', 'To transfer is success.');
                else
                {
                    $this->session->set_flashdata('message', 'To transfer is failed.');
                }
            }            
        }     
        else  

        $jackpot_rate = 0.0;
        $rank_rate = 0.0;
        $retdata = $this->adminapi->getcommission();
        if ($retdata != null)
            $jackpot_rate = $retdata['jackpot_rate'];
            $rank_rate = $retdata['rank_rate'];

        $this->load->view('dashboard');
        $this->load->view('sidebar');
        $this->load->view('topbar', array('user_name'=>$userinfo->name, 'notify_data'=>$notify_alert));
        $this->load->view('systemcommission', array('jackpot_rate'=>$jackpot_rate, 'rank_rate'=>$rank_rate));
        $this->load->view('footer');
    }

    public function system_calculation()
    {
        if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');
        $data = array();
        $data['user_name'] = $userinfo->name;
        $notify_alert = $this->db_model->get_all_notify(1);

        $this->load->view('dashboard');
        $this->load->view('sidebar');
        $this->load->view('topbar', array('user_name'=>$userinfo->name, 'notify_data'=>$notify_alert));
        $this->load->view('systemcalculation');
        $this->load->view('footer');
    }

    public function game_event()
    {
        if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');
        $data = array();
        $data['user_name'] = $userinfo->name;
        $notify_alert = $this->db_model->get_all_notify(1);

        $this->load->view('dashboard');
        $this->load->view('sidebar');
        $this->load->view('topbar', array('user_name'=>$userinfo->name, 'notify_data'=>$notify_alert));
        $this->load->view('gameevent');
        $this->load->view('footer');
    }

    public function game_jackpot()
    {
        if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');
        $data = array();
        $data['user_name'] = $userinfo->name;
        $notify_alert = $this->db_model->get_all_notify(1);

        $this->load->view('dashboard');
        $this->load->view('sidebar');
        $this->load->view('topbar', array('user_name'=>$userinfo->name, 'notify_data'=>$notify_alert));
        $this->load->view('gamejackpot');
        $this->load->view('footer');
    }

    public function game_log()
    {
        if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');
        $data = array();
        $data['user_name'] = $userinfo->name;
        $notify_alert = $this->db_model->get_all_notify(1);

        $this->load->view('dashboard');
        $this->load->view('sidebar');
        $this->load->view('topbar', array('user_name'=>$userinfo->name, 'notify_data'=>$notify_alert));
        $this->load->view('gamelog');
        $this->load->view('footer');
    }

    public function game_bots()
    {
        if ( !$this->session->userdata('is_login') )
            redirect('signin');

        $userinfo = $this->session->userdata('userinfo');
        $data = array();
        $data['user_name'] = $userinfo->name;
        $notify_alert = $this->db_model->get_all_notify(1);

        $this->load->view('dashboard');
        $this->load->view('sidebar');
        $this->load->view('topbar', array('user_name'=>$userinfo->name, 'notify_data'=>$notify_alert));
        $this->load->view('botmanage');
        $this->load->view('footer');
    }
}
?>
