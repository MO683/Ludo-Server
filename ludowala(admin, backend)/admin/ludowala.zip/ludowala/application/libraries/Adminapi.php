<?php


class Adminapi {

    private $api_link = "127.0.0.1:10006/adminapi";
    private $params = array();

    public function __construct() {
        $this->_ci = & get_instance();

        if ( ! $this->is_enabled())
        {
            log_message('error', 'Adminapi');
        }
    }

    public function is_enabled()
    {
        return function_exists('curl_init');
    }

    public function userlist($block_flag)
    {
        $this->params['req_type'] = "getuserlist";
        $this->params['block_flag'] = $block_flag;
        return $this->execute('POST');
    }

    public function user_block($u_id)
    {
        $this->params['req_type'] = "userblock";
        $this->params['u_id'] = $u_id;
        return $this->execute('POST');
    }

    public function user_unblock($u_id)
    {
        $this->params['req_type'] = "userunblock";
        $this->params['u_id'] = $u_id;
        return $this->execute('POST');
    }

    public function user_delete($u_id)
    {
        $this->params['req_type'] = "userdelete";
        $this->params['u_id'] = $u_id;
        return $this->execute('POST');
    }

    public function game_stats($flag)
    {
        $this->params['req_type'] = "gamestats";
        $this->params['req_flag'] = $flag;
        return $this->execute('POST');
    }

    public function transfermoney($u_id, $money)
    {
        $this->params['req_type'] = "transfermoney";
        $this->params['u_id'] = $u_id;
        $this->params['u_money'] = $money;
        return $this->execute('POST');
    }

    public function getbackmoney($u_id, $money)
    {
        $this->params['req_type'] = "getbackmoney";
        $this->params['u_id'] = $u_id;
        $this->params['u_money'] = $money;
        return $this->execute('POST');
    }

    public function getcommission()
    {
        $this->params['req_type'] = "getcommission";
        return $this->execute('POST');
    }

    public function setcommission($jackpot_rate, $rank_rate)
    {
        $this->params['req_type'] = "setcommission";
        $this->params['jackpot_rate'] = $jackpot_rate;
        $this->params['rank_rate'] = $rank_rate;
        return $this->execute('POST');
    }

    //private function execute(string $requestType = 'POST') {
    private function execute($requestType) {
        $ch = curl_init($this->api_link);
        if ($requestType === 'GET') {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
        } elseif ($requestType === 'PUT') {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
            //curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($this->params));
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($this->params));
        } elseif ($requestType === 'DELETE') {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
        } elseif ($requestType === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            //curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($this->params));
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($this->params));
        }
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $headers = array('Accept: *', 'Content-Type: application/json; charset=utf-8'); 
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $response = curl_exec($ch);
        curl_close($ch);

        return json_decode($response, true);
    }
}
